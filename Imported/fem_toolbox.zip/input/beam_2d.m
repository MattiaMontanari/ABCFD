function in_data = beam_2d (in_data)


in_data.ND = [   
         1   6    0;
         2   12   0;
         3   18   0;
         4   24   0;
         5   30   0;
         6   0    6;
         7   6    6;
         8   12   6;
         9   18   6;
         10  24   6;
         11  30   6;
         12  36   6];

E = 9e9;
A = .4;
I = 1e-4;
in_data.mater.rho=0;
rho = 2000;

in_data.EL = [  
        1  0   1   2   E  A  I rho;
        2  0   2   3   E  A  I rho;
        3  0   3   4   E  A  I rho;
        4  0   4   5   E  A  I rho;
        5  0   1   6   E  A  I rho;
        6  0   1   7   E  A  I rho;
        7  0   1   8   E  A  I rho;
        8  0   2   8   E  A  I rho;
        9  0   3   8   E  A  I rho;
       10  0   3   9   E  A  I rho;
       11  0   3   10  E  A  I rho;
       12  0   4   10  E  A  I rho;
       13  0   5   10  E  A  I rho;
       14  0   5   11  E  A  I rho;
       15  0   5   12  E  A  I rho;
       16  0   6    7  E  A  I rho;
       17  0   7    8  E  A  I rho;
       18  0   8    9  E  A  I rho;
       19  0   9   10  E  A  I rho;
       20  0   10  11  E  A  I rho;
       21  0   11  12  E  A  I rho];

in_data.mater.E=0; in_data.mater.A=0; in_data.mater.I=0;
in_data.q =  5.1e2*[ 0 0 -10 -10 0 0 0 0 0 0 0 0 0 0 0 -0 -0 -0 -10 -10 -10];

in_data.slaves(1).a = 3.*[1 2 3 4]-1;         % slaves dof's
in_data.master(1).a = 3.*[5]-1;               % master dof

in_data.DBC.dofs = 3.*[ 6]-1;                % dof's with displ BC's
in_data.DBC.displ= [ .03];                   % dof's with displ BC's

in_data.CON = [  
         6  0  0  0;
        12  0  0  0];
in_data.LOAD_ = [  
           1      0  -0e2   0;
           2      0  -0e2   0;
           3      0  -200e2 0;
           4      0  -0e2   0;
           5      0  -0e2   0];

in_data.MASS = [  
          1  10e4  10e4  0;
          2  10e4  10e4  0;
          3  10e4  10e4  0;   
          4  10e4  10e4  0;
          5  10e4  10e4  0;
          6  10e4  10e4  0;
          7  10e4  10e4  0;
          8  10e4  10e4  0;
          9  10e4  10e4  0;
         10  10e4  10e4  0;
         11  10e4  10e4  0;
         12  10e4  10e4  0];
in_data.dynam.TIMEH    = [ 'bedr.txt' ];         
in_data.dynam.delta_tm = [0.0079];               
in_data.dynam.TIMEHDIR = [0 1 0];                
in_data.dynam.TIMEHM   = [1:length(in_data.ND)*1];    
in_data.dynam.TIMEHPL  = [2*3-2];                
in_data.dynam.DAMP_C   = [0.06 0.06];           
in_data.dynam.DAMP_F   = [3];                    
in_data.dynam.ab       = [0.4 0.0001];           
in_data.dynam.MODA     = [1];                    % plot mode of vibration
