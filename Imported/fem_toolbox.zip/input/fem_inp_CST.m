function in_data = fem_inp_CST


in_data.ND = [   
   1   1   1;
   2   2.6 1;
   3   4.8 1;
   4   7   1;
   5   8   1;
   6   1.6 2.5;
   7   3   2.5;
   8   4.9 2.5;
   9   7   2.5;
   10  8   2.5;
   11  2.3 4;
   12  3.4 4;
   13  5   4;
   14  7   4;
   15  8   4;
   16  2.8 5;
   17  3.8 5;
   18  5.1 5;
   19  7   5;
   20  8   5;
   21  3.2 6;
   22  4.2 6;
   23  5.4 6;
   24  7.2 6;
   25  8.2 6;
   26  3.7 7;
   27  4.7 7;
   28  5.7 7;
   29  7.3 7;
   30  8.3 7;
   31  4.2 8;
   32  5.2 8;
   33  6.2 8;
   34  7.6 8;
   35  8.6 8;
   36  4.6 9;
   37  5.5 9;
   38  6.5 9;
   39  7.8 9;
   40  8.8 9;
   41  5   10;
   42  6   10;
   43  7   10;
   44  8   10;
   45  9   10];
   

in_data.mater.E = 9e6;
in_data.mater.h = 0.2;
in_data.mater.miu = 0.3;
in_data.mater.rho = 2000;
in_data.mater.rho=0;
rho=2500;

E = in_data.mater.E; h = in_data.mater.h; miu = in_data.mater.miu;

in_data.EL = [  
   1   4   1   2   6   E  h  miu rho;
   2   4   6   2   7   E  h  miu rho;
   3   4   2   3   7   E  h  miu rho;
   4   4   7   3   8   E  h  miu rho;
   5   4   3   4   8   E  h  miu rho;
   6   4   8   4   9   E  h  miu rho;
   7   4   9   4   5   E  h  miu rho;
   8   4   9   5  10   E  h  miu rho;
   9   4   6   7  11   E  h  miu rho;
  10   4   11  7  12   E  h  miu rho;
  11   4   7   8  12   E  h  miu rho;
  12   4   12  8  13   E  h  miu rho;
  13   4   8   9  13   E  h  miu rho;
  14   4   13   9  14   E  h  miu rho;
  15   4   14   9  10   E  h  miu rho;
  16   4   14  10  15   E  h  miu rho;
  17   4   11  12  16   E  h  miu rho;
  18   4   16  12  17   E  h  miu rho;
  19   4   12  13  17   E  h  miu rho;
  20   4   17  13  18   E  h  miu rho;
  21   4   13  14  18   E  h  miu rho;
  22   4   18  14  19   E  h  miu rho;
  23   4   19  14  15   E  h  miu rho;
  24   4   19  15  20   E  h  miu rho;
  25   4   16  17  21   E  h  miu rho;
  26   4   21  17  22   E  h  miu rho;
  27   4   17  18  22   E  h  miu rho;
  28   4   22  18  23   E  h  miu rho;
  29   4   18  19  23   E  h  miu rho;
  30   4   23  19  24   E  h  miu rho;
  31   4   19  20  24   E  h  miu rho;
  32   4   24  20  25   E  h  miu rho;
  33   4   21  22  26   E  h  miu rho;
  34   4   26  22  27   E  h  miu rho;
  35   4   22  23  27   E  h  miu rho;
  36   4   27  23  28   E  h  miu rho;
  37   4   23  24  28   E  h  miu rho;
  38   4   28  24  29   E  h  miu rho;
  39   4   24  25  29   E  h  miu rho;
  40   4   29  25  30   E  h  miu rho;
  41   4   26  27  31   E  h  miu rho;
  42   4   31  27  32   E  h  miu rho;
  43   4   27  28  32   E  h  miu rho;
  44   4   32  28  33   E  h  miu rho;
  45   4   28  29  33   E  h  miu rho;
  46   4   33  29  34   E  h  miu rho;
  47   4   34  29  30   E  h  miu rho;
  48   4   34  30  35   E  h  miu rho;
  49   4   36  31  32   E  h  miu rho;
  50   4   36  32  37   E  h  miu rho;
  51   4   32  33  37   E  h  miu rho;
  52   4   37  33  38   E  h  miu rho;
  53   4   33  34  38   E  h  miu rho;
  54   4   38  34  39   E  h  miu rho;
  55   4   39  34  35   E  h  miu rho;
  56   4   39  35  40   E  h  miu rho;
  57   4   36  37  41   E  h  miu rho;
  58   4   41  37  42   E  h  miu rho;
  59   4   37  38  42   E  h  miu rho;
  60   4   42  38  43   E  h  miu rho;
  61   4   38  39  43   E  h  miu rho;
  62   4   43  39  44   E  h  miu rho;
  63   4   44  39  40   E  h  miu rho;
  64   4   44  40  45   E  h  miu rho];


in_data.CON = [  
   1  0  0;
   2  0  0;
   3  0  0;
   4  0  0;
   5  0  0];

in_data.LOAD_ = [ 
    6   100e1       00e1;
   11   100e1       00e1;
   16   100e1       00e1;
   21   100e1       00e1;
   26   100e1        00e1;
   31   100e1        00e1;
   36   100e1        00e1;
   25   00e1         00e1;
   42   00e1        00e1;
   43   00e1        00e1];


in_data.dynam.TIMEH    = [ 'bedr.txt' ];       
in_data.dynam.delta_tm = [0.0079];             
in_data.dynam.TIMEHDIR = [0 1];                
in_data.dynam.TIMEHM   = [ 1:length(in_data.ND)*1]; 
in_data.dynam.TIMEHPL  = [41];               
in_data.dynam.DAMP_C   = [0.06 0.06];        
in_data.dynam.DAMP_F   = [3];                
in_data.dynam.ab       = [0.4 0.0001];       
% modal analysis
in_data.dynam.MODA     = [2];                
