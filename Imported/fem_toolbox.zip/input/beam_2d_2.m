function in_data = beam_2d_2 (in_data)

in_data.ND = [   
         1   0       0;
         2   .9    3.3;
         3   2.4   5.8;
         4   5.0   7.3;
         5   8       8;
         6   11    7.3;
         7   13.6  5.8;
         8   15.1  3.3;
         9   16      0;
         10  -1      0;
         11   0    3.8;
         12  1.7   6.5;
         13  4.5   8.4;
         14   8      9;
         15   11.5 8.4;
         16   14.3 6.5;
         17   16   3.8;
         18   17     0];

E = 3e11;
A = .25;
I = 1e-4;
in_data.mater.rho=0;
rho = 2000;

in_data.EL = [  
        1  0   1     2   E  A  I rho;
        2  0   2     3   E  A  I rho;
        3  0   3     4   E  A  I rho;
        4  0   4     5   E  A  I rho;
        5  0   5     6   E  A  I rho;
        6  0   6     7   E  A  I rho;
        7  0   7     8   E  A  I rho;
        8  0   8     9   E  A  I rho;
        9  0   10   11   E  A  I rho;
       10  0   11   12   E  A  I rho;
       11  0   12   13   E  A  I rho;
       12  0   13   14   E  A  I rho;
       13  0   14   15   E  A  I rho;
       14  0   15   16   E  A  I rho;
       15  0   16   17   E  A  I rho;
       16  0   17   18   E  A  I rho;
       17  0   1    11   E  A  I rho;
       18  0   11   3    E  A  I rho;
       19  0   3    13   E  A  I rho;
       20  0   13   5    E  A  I rho;
       21  0   5    15   E  A  I rho;
       22  0   7    15   E  A  I rho;
       23  0   7    17   E  A  I rho;
       24  0   9    17   E  A  I rho;
       25  0   2    11   E  A  I rho;
       26  0   3    12   E  A  I rho;
       27  0   4    13   E  A  I rho;
       28  0   5    14   E  A  I rho;
       29  0   6    15   E  A  I rho;
       30  0   7    16   E  A  I rho;
       31  0   8    17   E  A  I rho;
       32  0   9    18   E  A  I rho;
       33  0   1    10   E  A  I rho];

in_data.mater.E=0; in_data.mater.A=0; in_data.mater.I=0;

in_data.q =  5e2*[ -10 -0 -0 -0 -0 -0 -0 -0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
   

in_data.CON = [  
         1  0  0  0;
         9  0  0  0;
         18 0  0  0;
         10 0  0  0];
in_data.LOAD_ = [  
           14      10e4  -40e4   0];

in_data.MASS = [  
          1  10e4  30e4  10e6;
          2  10e4  30e4  10e6;
          3  10e4  30e4  10e6;
          4  10e4  30e4  10e6;
          5  10e4  30e4  10e6;
          6  10e4  30e4  10e6;
          7  10e4  30e4  10e6;
          8  10e4  30e4  10e6;
          9  10e4  30e4  10e6;
         10  10e4  30e4  10e6;
         11  10e4  30e4  10e6;
         12  10e4  30e4  10e6;
         13  10e4  30e4  10e6;
         14  10e4  30e4  10e6;
         15  10e4  30e4  10e6;
         16  10e4  30e4  10e6;
         17  10e4  30e4  10e6;
         18  10e4  30e4  10e6];
          
in_data.dynam.TIMEH    = [ 'bedr.txt' ];         
in_data.dynam.delta_tm = [0.0079];              
in_data.dynam.TIMEHDIR = [1 0 0];                
in_data.dynam.TIMEHM   = [1:length(in_data.EL)*3];
in_data.dynam.TIMEHPL  = [2*3-1];                
in_data.dynam.DAMP_C   = [0.06 0.06];          
in_data.dynam.DAMP_F   = [3];                 
in_data.dynam.ab       = [0.4 0.0001];        
in_data.dynam.MODA     = [1];                 
