function in_data = fem3D_tetrah

in_data.ND = [ 
   1 0   0 0;
   2 10  0 0;
   3  5 10 0;
   4  5  5 10];
  

in_data.mater.E    = 1e6;
in_data.mater.miu  = 0.3;
in_data.mater.rho  = 300; 

E = in_data.mater.E; rho = in_data.mater.rho; miu = in_data.mater.miu;

in_data.EL = [
   1 10  1  2  3 4 E  miu rho];


in_data.CON = [ 
   1 0 0 0;
   2 0 0 0;
   3 0 0 0];

in_data.LOAD_ = [
         4  100e1  -100e1 0];


in_data.MASS = [  ];          



in_data.dynam.TIMEH    = [ 'bedr.txt' ]; 
in_data.dynam.delta_tm = [0.0079];       
in_data.dynam.TIMEHDIR = [1 0 1];        
in_data.dynam.TIMEHM   = [1:length(in_data.EL)*3];  
in_data.dynam.TIMEHPL  = [4*3-0];               
in_data.dynam.DAMP_C   = [0.06 0.06];        
in_data.dynam.DAMP_F   = [3];                
in_data.dynam.ab       = [0.4 0.0001];       

in_data.dynam.MODA     = [1];                
