function in_data = fem3D_inp_frame (in_data)

in_data.ND = [   1   0   0   0;
   2   3   0   0;
   3   6   0   0;
   4   0   2   0;
   5   3   2   0;
   6   6   2   0;
   7   0   4   0;
   8   3   4   0;
   9   6   4   0;
   10  0   0   2;
   11  3   0   2;
   12  6   0   2;
   13  0   2   2;
   14  3   2   2;
   15  6   2   2;
   16  0   4   2;
   17  3   4   2;
   18  6   4   2;
   19  0   0   4;
   20  3   0   4;
   21  6   0   4;
   22  0   2   4;
   23  3   2   4;
   24  6   2   4;
   25  0   4   4;
   26  3   4   4;
   27  6   4   4];


E = 8e7;
G = 3e6;
b = 0.3;
ho = 0.3;
rho = 25000;

in_data.mater.rho=0; in_data.mater.b=0; in_data.mater.ho=0;
in_data.mater.E=0; in_data.mater.A=0; in_data.mater.I=0; in_data.mater.G=0;
in_data.EL = [  
   1 3   1   10   E  G  b  ho rho;
   2 3   2   11   E  G  b  ho rho;
   3 3   3   12   E  G  b  ho rho;
   4 3   4   13   E  G  b  ho rho;
   5 3   5   14   E  G  b  ho rho;
   6 3   6   15  E  G  b   ho rho;
   7 3   7   16  E  G  b   ho rho;
   8 3   8   17  E  G  b   ho rho;
   9 3   9   18  E  G  b   ho rho;
   10 3  10  19  E  G  b   ho rho;
   11 3  11  20  E  G  b   ho rho;
   12 3  12  21  E  G  b   ho rho;
   13 3  13  22  E  G  b   ho rho;
   14 3  14  23  E  G  b   ho rho;
   15 3  15  24  E  G  b   ho rho;
   16 3  16  25  E  G  b   ho rho;
   17 3  17  26  E  G  b   ho rho;
   18 3  18  27  E  G  b   ho rho;
   19 3  10  11  E  G  b   ho rho;
   20 3  11  12  E  G  b   ho rho;
   21 3  13  14  E  G  b   ho rho;
   22 3  14  15  E  G  b   ho rho;
   23 3  16  17  E  G  b   ho rho;
   24 3  17  18  E  G  b   ho rho;
   25 3  19  20  E  G  b   ho rho;
   26 3  20  21  E  G  b   ho rho;
   27 3  22  23  E  G  b   ho rho;
   28 3  23  24  E  G  b   ho rho;
   29 3  25  26  E  G  b   ho rho;
   30 3  26  27  E  G  b   ho rho;
   31 3  10  13  E  G  b   ho rho;
   32 3  13  16  E  G  b   ho rho;
   33 3  11  14  E  G  b   ho rho;
   34 3  14  17  E  G  b   ho rho;
   35 3  12  15  E  G  b   ho rho;
   36 3  15  18  E  G  b   ho rho;
   37 3  19  22  E  G  b   ho rho;
   38 3  22  25  E  G  b   ho rho;
   39 3  20  23  E  G  b   ho rho;
   40 3  23  26  E  G  b   ho rho;
   41 3  21  24  E  G  b   ho rho;
   42 3  24  27  E  G  b   ho rho];

in_data.CON = [  
         1  0  0  0  0  0  0;
         2  0  0  0  0  0  0;
         3  0  0  0  0  0  0;
         4  0  0  0  0  0  0;
         5  0  0  0  0  0  0;
         6  0  0  0  0  0  0;
         7  0  0  0  0  0  0;
         8  0  0  0  0  0  0;
         9  0  0  0  0  0  0];

in_data.LOAD_ = [  
           22   0e1      10e1    0    0         0    0;
           23   -10e1    0e1     0    0         0    0;
           24   0e1      -0e1    0    0         0    0];

in_data.MASS = [.1 .1 .1 .1 .1 .1 .1];

in_data.dynam.TIMEH     = [ 'bedr.txt' ];
in_data.dynam.delta_tm  = [0.0079];
in_data.dynam.TIMEHDIR  = [1 0 0 0 0 0];
in_data.dynam.TIMEHM    = [1:1:length(in_data.ND)*6];
in_data.dynam.TIMEHPL   = [19*6-2];
in_data.dynam.DAMP_C    = [0.06 0.06];
in_data.dynam.DAMP_F    = [3];        
in_data.dynam.ab        = [0.04 0.001]; 
in_data.dynam.MODA      = [1];          
