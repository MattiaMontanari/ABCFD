function in_data = Cantilever_Beam(in_data)


% Length, height, wide....
x=1.00;
y=.1;
z=.1;

%Subdivide beam in elements of length dx,dy,dz....
dx = 0.025;
dy = 0.025;
dz = 0.025;



%Build "in_data.ND = Build" and "in_data.EL = Build2"

Build2 = [];
Build = [];
Count = 1;
Count2=1;
z0=0;
for u = 1:z/dz+1
    y0 = 0;
    for k = 1:y/dy+1
        x0=0;
        for i = 1:x/dx+1;
            Build(Count,1) = Count;
            Build(Count,2) = x0;
            Build(Count,3) = y0;
            Build(Count,4) = z0;
            if ( (i <= x/dx)  &&  (k <= y/dy)  && (u <= z/dz))
                Build2(Count2,1) = Count2;
                Build2(Count2,2) = 6;
                Build2(Count2,3) = Build(Count,1);
                Build2(Count2,4) = Build(Count,1)+1;
                Build2(Count2,5) = Build(Count,1) + x/dx+2;
                Build2(Count2,6) = Build(Count,1)+ x/dx+1  ;
                Build2(Count2,7) = Build2(Count2,3) + (x/dx+1)*(y/dy+1);
                Build2(Count2,8) = Build2(Count2,4)+ (x/dx+1)*(y/dy+1)  ;
                Build2(Count2,9) = Build2(Count2,5) + (x/dx+1)*(y/dy+1);
                Build2(Count2,10)= Build2(Count2,6)+ (x/dx+1)*(y/dy+1)  ;

                Count2= Count2 + 1;
            end
            x0 = x0+dx;
            Count = Count + 1;
        end
        y0 = y0+dy;
    end
    z0 = z0+dz;
end






in_data.mater.E    = 2e11;
in_data.mater.miu  = 0.3;
in_data.mater.rho  = 7890; 

E = in_data.mater.E; 
rho = in_data.mater.rho; 
miu = in_data.mater.miu;

Build2(:,11) = E;
Build2(:,12) = miu;
Build2(:,13) = rho;


in_data.ND = Build;
in_data.EL = Build2;


[s1,s2] = size(Build2);
for i = 1:s1
    Mass(i,1) = i;
    Mass(i,2) = 10e4;
    Mass(i,3) = 30e4;
    Mass(i,4) = 10e6;
end
in_data.MASS = Mass;



%Set fixed displace at the end of the beam (if x-coordinate of node >= 99.9 mm)
[s1,s2] = size(Build);
Count=1;
for i = 1:s1
    %x
    if (Build(i,2) >= 0.99)
    Con( Count,1) = Build(i,1);
    Con( Count,2) = 0;
    Con( Count,3) = 0;
    Con( Count,4) = 0;
    Count = Count+1;
    end
    end
in_data.CON = Con;





%Set load to the other end of the beam (if x-coordinate of node <= 0.5 mm)
[s1,s2] = size(Build);
Count=1;
Load = [];
for i = 1:s1
    if (Build(i,2) <= 0)
        Load( Count,1) = Build(i,1);
        Load( Count,2) = 0;
        Load( Count,3) = 0;
        Count = Count+1;
    end
end

%Set ammount of Load (10N/number of applied nods)
[s1,s2] = size(Load)
Load(:,4) = -10/s1;
Load

in_data.LOAD_ = Load;

        


in_data.dynam.TIMEH    = [ 'bedr.txt' ];
in_data.dynam.delta_tm = [0.0079];      
in_data.dynam.TIMEHDIR = [1 0 1];       
in_data.dynam.TIMEHM   = [1:length(in_data.EL)*3]; 
in_data.dynam.TIMEHPL  = [31*3-0];              
in_data.dynam.DAMP_C   = [0.06 0.06];         
in_data.dynam.DAMP_F   = [3];                 
in_data.dynam.ab       = [0.4 0.0001];        
in_data.dynam.MODA     = [3];                 
