function in_data = fem3D_brick

in_data.ND = [ 
   1 0   0 0;
   2 5   0 0;
   3 10  0 0;
   4 0   5 0;
   5 5   5 0;
   6 10  5 0;
   7 0  10 0;
   8 5  10 0;
   9 10 10 0;
  10  0  0 2;
  11  5  0 2;
  12 10  0 2;
  13  0  5 2;
  14  5  5 2;
  15 10  5 2;
  16  0 10 2;
  17  5 10 2;
  18 10 10 2;
  19  0  0 4;
  20  5  0 4;
  21 10  0 4;
  22  0  5 4;
  23  5  5 4;
  24 10  5 4;
  25  0 10 4;
  26  5 10 4;
  27 10 10 4;
  28  0  0 6;
  29  5  0 6;
  30 10  0 6;
  31  0  5 6;
  32  5  5 6;
  33 10  5 6;
  34  0 10 6;
  35  5 10 6;
  36 10 10 6];
  

in_data.mater.E    = 1e6;
in_data.mater.miu  = 0.3;
in_data.mater.rho  = 300; 

E = in_data.mater.E; rho = in_data.mater.rho; miu = in_data.mater.miu;
in_data.EL = [
   1  6  1  2  5 4  10  11  14 13  E  miu rho;
   2  6  2  3  6  5 11  12  15 14  E  miu rho;
   3  6  4  5  8  7 13  14  17 16  E  miu rho;
   4  6  5  6  9  8 14  15  18 17  E  miu rho;
   5  6  10 11 14 13 19 20  23 22  E  miu rho;
   6  6  11 12 15 14  20 21 24 23  E  miu rho;
   7  6  13 14 17 16 22  23 26 25  E  miu rho;
   8  6  14 15 18 17 23  24 27 26  E  miu rho;
   9  6  19 20 23 22 28  29 32 31  E  miu rho;
  10  6  20 21 24 23 29  30 33 32  E  miu rho;
  11  6  22 23 26 25 31  32 35 34  E  miu rho;
  12  6  23 24 27 26 32  33 36 35  E  miu rho];


in_data.CON = [ 
   1 0 0 0;
   2 0 0 0;
   3 0 0 0;
   4 0 0 0;
   5 0 0 0;
   6 0 0 0;
   7 0 0 0;
   8 0 0 0;
   9 0 0 0];
in_data.LOAD_ = [
         28  00e1  100e1 0;
         29  00e1 00e1 0;
         30  00e1 00e1 0;
         31  200e1 00e1 0];

in_data.MASS = [
          1  10e4  30e4  10e6;
          2  10e4  30e4  10e6;
          3  10e4  30e4  10e6;
          4  10e4  30e4  10e6;
          5  10e4  30e4  10e6;   
          6  10e4  30e4  10e6;
          7  10e4  30e4  10e6;
          8  10e4  30e4  10e6;
          9  10e4  30e4  10e6;
          10 10e4  30e4  10e6;
          11 10e4  30e4  10e6;
          12 10e4  30e4  10e6;
          13 10e4  30e4  10e6;
          14 10e4  30e4  10e6;
          15 10e4  30e4  10e6;
          16 10e4  30e4  10e6;
          17 10e4  30e4  10e6;
          18 10e4  30e4  10e6;
          19 10e4  30e4  10e6;
          20 10e4  30e4  10e6;   
          21 10e4  30e4  10e6;
          22 10e4  30e4  10e6;
          23 10e4  30e4  10e6;
          24 10e4  30e4  10e6;
          25 10e4  30e4  10e6;
          26 10e4  30e4  10e6;
          27 10e4  30e4  10e6;
          28 10e4  30e4  10e6;
          29 10e4  30e4  10e6;
          30 10e4  30e4  10e6;
          31 10e4  30e4  10e6;
          32 10e4  30e4  10e6;
          33 10e4  30e4  10e6;
          34 10e4  30e4  10e6;   
          35 10e4  30e4  10e6;
          36 10e4  30e4  10e6];          


in_data.dynam.TIMEH    = [ 'bedr.txt' ];
in_data.dynam.delta_tm = [0.0079];      
in_data.dynam.TIMEHDIR = [1 0 1];       
in_data.dynam.TIMEHM   = [1:length(in_data.EL)*3]; 
in_data.dynam.TIMEHPL  = [31*3-0];              
in_data.dynam.DAMP_C   = [0.06 0.06];         
in_data.dynam.DAMP_F   = [3];                 
in_data.dynam.ab       = [0.4 0.0001];        
in_data.dynam.MODA     = [1];                 
