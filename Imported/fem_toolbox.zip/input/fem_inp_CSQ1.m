function in_data = fem_inp_CSQ1


in_data.ND = [ 1 0 0;
   2 7  0;
   3 10 0;
   4 0  4;
   5 7  4;
   6 10 4;
   7 0  10;
   8 7  10;
   9 10 10];

in_data.mater.E     = 0;
E=10e9;
in_data.mater.h     = 0;
h=0.6;
in_data.mater.miu   = 0;
miu =0.3;
in_data.mater.rho  = 0; 
rho = 2200;

in_data.EL = [
   1  5  1  2  5  4   E [1 1 1 1].*h miu rho rho ;
   2  5  2  3  6  5   E [1 1 1 1].*h miu rho rho ;
   3  5  4  5  8  7   E [1 1 1 1].*h miu rho rho ;
   4  5  5  6  9  8   E [1 1 1 1].*h miu rho rho ];


in_data.CON = [ 1 0 0;
   2 0 0;
   3 0 0];

in_data.LOAD_ = [4  00e1  00e1;
         7  00e1 00e1;
         8  00e1 00e1;
         9  100e1 00e1];


in_data.MASS = [  4  10e4  30e4  10e6;
          5  10e4  30e4  10e6;   
          6  10e4  30e4  10e6;
          7  10e4  30e4  10e6;
          8  10e4  30e4  10e6;
          9  10e4  30e4  10e6;
          10 10e4  30e4  10e6;
          11 10e4  30e4  10e6;
          12 10e4  30e4  10e6;
          13 10e4  30e4  10e6;
          14 10e4  30e4  10e6;
          15 10e4  30e4  10e6];

in_data.dynam.TIMEH    = [ 'bedr.txt' ]; 
in_data.dynam.delta_tm = [0.0079];       
in_data.dynam.TIMEHDIR = [1 1];          
in_data.dynam.TIMEHM   = [1:length(in_data.ND)*2];
in_data.dynam.TIMEHPL  = [17];               
in_data.dynam.DAMP_C   = [0.04 0.04];        
in_data.dynam.DAMP_F   = [3];                
in_data.dynam.ab       = [0.4 0.0001];       

in_data.dynam.MODA     = [1];                
