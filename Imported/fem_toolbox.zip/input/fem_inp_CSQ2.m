function in_data = fem_inp_CSQ2 (in_data)

in_data.ND = [ 
   1 0 0;
   2 1 0;
   3 2 0;
   4 3 0;
   5 4 0;
   6 5 0;
   7 6 0;
   8 0 1;
   9 1 1;
  10 2 1;
  11 3 1;
  12 4 1;
  13 5 1;
  14 6 1;
  15 0 2;
  16 1 2;
  17 2 2;
  18 3 2;
  19 4 2;
  20 5 2;
  21 6 2;
  22 0 3;
  23 1 3;
  24 2 3;
  25 3 3;
  26 4 3;
  27 5 3;
  28 6 3;
  29 0 4;
  30 1 4;
  31 2 4;
  32 3 4;
  33 4 4;
  34 5 4;
  35 6 4;
  36 0 5;
  37 1 5;
  38 2 5;
  39 3 5;
  40 4 5;
  41 5 5;
  42 6 5;
  43 0 6;
  44 1 6;
  45 2 6;
  46 3 6;
  47 4 6;
  48 5 6;
  49 6 6;
  50 0 7;
  51 1 7;
  52 2 7;
  53 3 7;
  54 4 7;
  55 5 7;
  56 6 7];

in_data.mater.E = 1e7;
in_data.mater.h = 0.6;
in_data.mater.miu = 0.3;
in_data.mater.rho =0;

E = in_data.mater.E; h = in_data.mater.h; miu = in_data.mater.miu;
rhoX = 5000;  rhoY = 5000;
in_data.PML.ex =1; in_data.PML.ey =1+0.1i;

in_data.EL = [
   1  5  1  2  9  8   E  [1 1 1 1]  miu rhoX rhoY;
   2  5  2  3 10  9   E  [1 1 1 1]  miu rhoX rhoY;
   3  5  3  4 11 10   E  [1 1 1 1]  miu rhoX rhoY;
   4  5  4  5 12 11   E  [1 1 1 1]  miu rhoX rhoY;
   5  5  5  6 13 12   E  [1 1 1 1]  miu rhoX rhoY;
   6  5  6  7 14 13   E  [1 1 1 1]  miu rhoX rhoY;
   7  5  8  9 16 15   E  [1 1 1 1]  miu rhoX rhoY;
   8  5  9 10 17 16   E  [1 1 1 1]  miu rhoX rhoY;
   9  5 10 11 18 17   E  [1 1 1 1]  miu rhoX rhoY;
  10  5 11 12 19 18   E  [1 1 1 1]  miu rhoX rhoY;
  11  5 12 13 20 19   E  [1 1 1 1]  miu rhoX rhoY;
  12  5 13 14 21 20   E  [1 1 1 1]  miu rhoX rhoY;
  13  5 15 16 23 22   E  [1 1 1 1]  miu rhoX rhoY;
  14  5 16 17 24 23   E  [1 1 1 1]  miu rhoX rhoY;
  15  5 17 18 25 24   E  [1 1 1 1]  miu rhoX rhoY;
  16  5 18 19 26 25   E  [1 1 1 1]  miu rhoX rhoY;
  17  5 19 20 27 26   E  [1 1 1 1]  miu rhoX rhoY;
  18  5 20 21 28 27   E  [1 1 1 1]  miu rhoX rhoY;
  19  5 22 23 30 29   E  [1 1 1 1]  miu rhoX rhoY;
  20  5 23 24 31 30   E  [1 1 1 1]  miu rhoX rhoY;
  21  5 24 25 32 31   E  [1 1 1 1]  miu rhoX rhoY;
  22  5 25 26 33 32   E  [1 1 1 1]  miu rhoX rhoY;
  23  5 26 27 34 33   E  [1 1 1 1]  miu rhoX rhoY;
  24  5 27 28 35 34   E  [1 1 1 1]  miu rhoX rhoY;
  25  5 29 30 37 36   E  [1 1 1 1]  miu rhoX rhoY;
  26  5 30 31 38 37   E  [1 1 1 1]  miu rhoX rhoY;
  27  5 31 32 39 38   E  [1 1 1 1]  miu rhoX rhoY;
  28  5 32 33 40 39   E  [1 1 1 1]  miu rhoX rhoY;
  29  5 33 34 41 40   E  [1 1 1 1]  miu rhoX rhoY;
  30  5 34 35 42 41   E  [1 1 1 1]  miu rhoX rhoY;
  31  5 36 37 44 43   E  [1 1 1 1]  miu rhoX rhoY;
  32  5 37 38 45 44   E  [1 1 1 1]  miu rhoX rhoY;
  33  5 38 39 46 45   E  [1 1 1 1]  miu rhoX rhoY;
  34  5 39 40 47 46   E  [1 1 1 1]  miu rhoX rhoY;
  35  5 40 41 48 47   E  [1 1 1 1]  miu rhoX rhoY;
  36  5 41 42 49 48   E  [1 1 1 1]  miu rhoX rhoY;
  37  5 43 44 51 50   E  [1 1 1 1]  miu rhoX rhoY;
  38  5 44 45 52 51   E  [1 1 1 1]  miu rhoX rhoY;
  39  5 45 46 53 52   E  [1 1 1 1]  miu rhoX rhoY;
  40  5 46 47 54 53   E  [1 1 1 1]  miu rhoX rhoY;
  41  5 47 48 55 54   E  [1 1 1 1]  miu rhoX rhoY;
  42  5 48 49 56 55   E  [1 1 1 1]  miu rhoX rhoY];


in_data.slaves(1).a = 2.*[37:40]-0;            % slaves dof's
in_data.master(1).a = 2.*[41]-0;                % master dof

in_data.DBC.dofs = 2.*[3 4 5]-0;                 % dof's with displ BC's
in_data.DBC.displ= [.0002 .0003 .0002];                   % dof's with displ BC's
 


in_data.CON = [ 1 0 0;
   2 0 0;
   3 0 0;
   4 0 0;
   5 0 0;
   6 0 0;
   7 0 0];
in_data.LOAD_ = [ 
         28  -100e1 00e1;
         53  00e1 00e1];

in_data.MASS = [  4  10e4  30e4  10e6;
          5  10e4  30e4  10e6;   
          6  10e4  30e4  10e6;
          7  10e4  30e4  10e6;
          8  10e4  30e4  10e6;
          9  10e4  30e4  10e6;
          10 10e4  30e4  10e6;
          11 10e4  30e4  10e6;
          12 10e4  30e4  10e6;
          13 10e4  30e4  10e6;
          14 10e4  30e4  10e6;
          15 10e4  30e4  10e6];

in_data.dynam.TIMEH    = [ 'bedr.txt' ]; 
in_data.dynam.delta_tm = [0.0079];       
in_data.dynam.TIMEHDIR = [0 1];          
in_data.dynam.TIMEHM   = [22:56];        
in_data.dynam.TIMEHPL  = [51*2-1];       
in_data.dynam.DAMP_C   = [0.04 0.04];    
in_data.dynam.DAMP_F   = [3];            
in_data.dynam.ab       = [0.4 0.0001];   
% modal analysis
in_data.dynam.MODA     = [2];            
