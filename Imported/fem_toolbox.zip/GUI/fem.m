function varargout = fem(varargin)
% FEM Application M-file for fem.fig
%    FIG = FEM launch fem GUI.
%    FEM('callback_name', ...) invoke the named callback.

% =========================================================================
% FEM analysis toolbox for solid mechanics.
% Author:          Anton Zaicenco <a.zaicenco@codedevelopment.net>
% Project started: Aug 2004
% Version:         1.2.2 (Oct 2011)
% =========================================================================

% -------------------------------------------------------------------------

if nargin == 0  % LAUNCH GUI
    % Generate a structure of handles to pass to callbacks, and store it
	fig = openfig(mfilename,'reuse');
	handles = guihandles(fig);
	guidata(fig, handles);
	if nargout > 0
		varargout{1} = fig;
	end
elseif ischar(varargin{1}) % INVOKE NAMED SUBFUNCTION OR CALLBACK
	try
		[varargout{1:nargout}] = feval(varargin{:}); % FEVAL switchyard
	catch
		disp(lasterr);
	end
end


% -------------------------------------------------------------------------
function varargout = loaddata_Callback(h, eventdata, handles, varargin)

dPath = which ('inpfiles.txt'); %    path to data directory
cd (dPath(1:end-12));           %    smth like: D:\matlabR12\work\fem\input
!time /t > inpfiles.txt

set(handles.text3, 'ForegroundColor',[0 0 0]);
set(handles.text4, 'ForegroundColor',[0 0 0]);
set(handles.text12,'ForegroundColor',[0 0 0]);

[nf,cf] = uigetfile('*.m',' Load input data ');

if length(cf)>1 set(handles.text7,'string',[cf ' ' nf]); end;
for i=1:length(nf)
    if nf(i)~='.' AA(i)=nf(i); end;
    if nf(i)=='.' break; end;
end;
if nf~=0
    handles.filename = AA;
    handles.in_data = eval (AA); 
    in_data = handles.in_data;
    if  isfield(handles,'shownodes')
        if handles.shownodes==1 
            plot_fem_data(in_data,1);
        else plot_fem_data(in_data,0);
        end
    else plot_fem_data(in_data,0);
    end;
    format long;
    set(handles.text3,'string',[ num2str(size(in_data.ND,1))]);
    set(handles.text3,'ForegroundColor',[1 0 0]);
    set(handles.text12,'string',[ num2str(size(in_data.EL,1))]);
    set(handles.text12,'ForegroundColor',[1 0 0]);

    % handles.obj.dofN -- dof per node. handles.obj.type - EL type (5 char)
    [dofN,EL_TYPE] = type_of_elem (in_data);
    switch EL_TYPE
        case {0,1,2}
            handles.in_data.dofN = dofN; handles.in_data.type = '2dbeam';
        case {31}
            handles.in_data.dofN = dofN; handles.in_data.type = '3dtrus';
        case {3}
            handles.in_data.dofN = dofN; handles.in_data.type = '3dbeam';
        case {4,5,51}
            handles.in_data.dofN = dofN; handles.in_data.type = 'cstcsq';
        case {6}
            handles.in_data.dofN = dofN; handles.in_data.type = '3dbrik';
        case {9}
            handles.in_data.dofN = dofN; handles.in_data.type = 'bciz  ';
        case {10}
            handles.in_data.dofN = dofN; handles.in_data.type = 'tetrah';
    end

    set(handles.text4,'string',[ num2str(dofN*size(in_data.ND,1))]);
    set(handles.text4,'ForegroundColor',[1 0 0]);
    format;
end
guidata(h, handles);    
                        


% --------------------------------------------------------------------
function varargout = visualize_Callback(h, eventdata, handles, varargin)

if  isfield(handles,'run')
    if  isfield(handles.run,'animate')
        if  isfield(handles.run.animate,'ok')
            if handles.run.animate.ok==1
                in_data = handles.in_data;
                if isfield(handles,'resp')
                    resp = handles.resp;
                end
                %handles.run.animate.ok=1;
                animate_dyn_response (resp,in_data);
            end
        end
    end
end

guidata(h, handles);

% --------------------------------------------------------------------
function varargout = checkbox1_Callback(h, eventdata, handles, varargin)
if (get(h,'Value') == get(h,'Max'))
    handles.run.static=1;% then checkbox is checked-take approriate action
    handles.ta(1)=1;
else
    handles.run.static=0;% checkbox is not checked-take approriate action
    handles.ta(1)=0;
end
guidata(h, handles);


% --------------------------------------------------------------------
function varargout = checkbox2_Callback(h, eventdata, handles, varargin)
if (get(h,'Value') == get(h,'Max'))
    handles.run.dynamic=1;% then checkbox is checked-take approriate action
    handles.ta(2)=1;
else
    handles.run.dynamic=0;% checkbox is not checked-take approriate action
    handles.ta(2)=0;
end
guidata(h, handles);


% --------------------------------------------------------------------
function varargout = checkbox3_Callback(h, eventdata, handles, varargin)
if (get(h,'Value') == get(h,'Max'))
    handles.run.modal=1;% then checkbox is checked-take approriate action
    handles.ta(3)=1;
else
    handles.run.modal=0;% checkbox is not checked-take approriate action
    handles.ta(3)=0;
end
guidata(h, handles);


% --------------------------------------------------------------------
function varargout = pushbutton2_Callback(h, eventdata, handles, varargin)
handles.ta = [0 0 0];
if  isfield(handles,'run') & isfield(handles,'in_data')
    if  isfield(handles.run,'static') 
        if handles.run.static==1
            in_data = handles.in_data; handles.ta(1) = 1; showPS=0;
            if  isfield(handles,'show')
                if handles.show.PS==1 showPS=1; end;
                if handles.show.PS==0 showPS=0; end;
            end
        end;
    end
    if  isfield(handles.run,'dynamic') 
        if handles.run.dynamic==1
            handles.ta(2) = 1; showPS = 1;
            dofN = handles.in_data.dofN;
            % plot point in blue at the main form:
            pax = gca;
            main_form_data_plot (handles,handles.in_data,pax,1);
            handles.run.animate.ok=1;
        end
    end
    if  isfield(handles.run,'modal') 
        if handles.run.modal==1  handles.ta(3) = 1; showPS = 1;  end;
    end
    if length(find(handles.ta==1))>0  
        [handles.obj,handles.resp] = ...
            fem_run (handles.in_data,handles.ta,handles.obj,handles.L,handles.break_K,showPS);
    end
end;         
guidata(h, handles);

% --------------------------------------------------------------------
function varargout = pushbutton1_ButtondownFcn(h, eventdata, handles, varargin)
% Stub for ButtondownFcn of the uicontrol handles.pushbutton1.
%disp('pushbutton1 ButtondownFcn not implemented yet.')


% --------------------------------------------------------------------
function varargout = checkbox1_ButtondownFcn(h, eventdata, handles, varargin)
% Stub for ButtondownFcn of the uicontrol handles.checkbox1.
%disp('checkbox1 ButtondownFcn not implemented yet.')


% --------------------------------------------------------------------
function varargout = radiobutton2_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.radiobutton2.
%disp('radiobutton2 Callback not implemented yet.')

% --------------------------------------------------------------------
function varargout = radiobutton3_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.radiobutton3.
%disp('radiobutton3 Callback not implemented yet.')

% --------------------------------------------------------------------
function varargout = pushbutton2_ButtondownFcn(h, eventdata, handles, varargin)
% Stub for ButtondownFcn of the uicontrol handles.pushbutton2.
%disp('pushbutton2 ButtondownFcn not implemented yet.')

% --------------------------------------------------------------------
% "EXIT" button:
function varargout = pushbutton5_Callback(h, eventdata, handles, varargin)
if isfield(handles,'figure1') & ishandle(handles.figure1),
    close(handles.figure1);
end
% Stub for Callback of the uicontrol handles.pushbutton5.
sp_=sprintf('\n');
disp([sp_ '  Thank you for using FEM toolbox' sp_])

% --------------------------------------------------------------------
function varargout = edit1_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.edit1.
%disp('edit1 Callback not implemented yet.')

% --------------------------------------------------------------------
function varargout = text3_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.text3.
%disp('text3 Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = pushbutton6_Callback(h, eventdata, handles, varargin)
handles.run.rsm=1;
rsm_simul (handles);
guidata(h, handles);
% Stub for Callback of the uicontrol handles.pushbutton6.


% --------------------------------------------------------------------
function varargout = pushbutton7_Callback(h, eventdata, handles, varargin)
rsm_pdf(handles);
guidata(h, handles);
% Stub for Callback of the uicontrol handles.pushbutton7.
% disp('pushbutton7 Callback not implemented yet.')


% --------------------------------------------------------------------
% "Show nodes" checkbox:
function varargout = checkbox8_Callback(h, eventdata, handles, varargin)
if (get(h,'Value') == get(h,'Max'))
    handles.shownodes=1;
else
    handles.shownodes=0;
end
guidata(h, handles);
% Stub for Callback of the uicontrol handles.checkbox8.



% --------------------------------------------------------------------
% "SAVE TO OBJ EPS" button:
function varargout = pushbutton8_Callback(h, eventdata, handles, varargin)
saveOBJECTeps; 
% Stub for Callback of the uicontrol handles.pushbutton8.



% --------------------------------------------------------------------
% "PS" checkbox:
function varargout = checkbox9_Callback(h, eventdata, handles, varargin)
if (get(h,'Value') == get(h,'Max'))
    handles.show.PS=1;
else
    handles.show.PS=0;
end
guidata(h, handles);
% Stub for Callback of the uicontrol handles.checkbox9.
% disp('checkbox9 Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = figure1_CreateFcn(h, eventdata, handles, varargin)
% Stub for CreateFcn of the figure handles.figure1.
% disp('figure1 CreateFcn not implemented yet.')


% --------------------------------------------------------------------
function varargout = pushbutton9_Callback(h, eventdata, handles, varargin)
handles.run.ssfem=1;
ssfem_simul (handles);
guidata(h, handles);
% Stub for Callback of the uicontrol handles.pushbutton9.
%disp('pushbutton9 Callback not implemented yet.')


% --------------------------------------------------------------------
function varargout = pushbutton10_Callback(h, eventdata, handles, varargin)
% Stub for Callback of the uicontrol handles.pushbutton10.
% disp('pushbutton10 Callback not implemented yet.')



function slider2_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
if  isfield(handles,'filename')
    if length(handles.filename)>0
     %  [handles.obj,handles.resp] = fem_run (handles.in_data,handles.ta);
       type_analysis = [1 1 1];
       [handles.obj,handles.L,handles.break_K] = build_object_KM (handles.in_data,type_analysis);
        guidata(hObject, handles);
    end
end

% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB


