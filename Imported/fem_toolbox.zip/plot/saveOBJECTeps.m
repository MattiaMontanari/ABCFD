function saveOBJECTeps

% saves image plot from main GUI to ..\tmp\obj.eps

A = which ('tmp_dir.txt');     
cd (A(1:end-12));              

h=gca;
hgsave(h,'guifig');
h2=figure(29874);
openfig('guifig.fig','new');
print( h2, '-deps','-r800', 'obj' );
close(h2);
delete guifig.fig;