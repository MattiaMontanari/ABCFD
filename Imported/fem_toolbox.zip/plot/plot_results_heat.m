function plot_results_heat ( in_data, resp, dof, NF, showPS) 

% PLOT temperatures (2D)
% =============================================================================
warning off

   
if 1

   figure(NF); hold off;

   % ****************************************************************************************
   for i=1:size(in_data.EL)
           node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
           node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
           node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
           trisurf([1 2 3],in_data.ND([node1 node2 node3],2),...
               in_data.ND([node1 node2 node3],3),resp.static.temperature([node1 node2 node3]));
           hold on;
   end
   % ****************************************************************************************

   
   shading interp; axis equal;  colormap(hsv); lighting phong;
   axis off; title('temperature field ');
   cb=colorbar('location','EastOutside');
   view(2); hold on




end
% ===========================================================================END
