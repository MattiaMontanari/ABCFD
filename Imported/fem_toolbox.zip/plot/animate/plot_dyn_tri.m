function plot_dyn_tri ( in_data, D, ind, dof, max_D_z, NF) 

if 1

   figure(NF);
   maxX = max(in_data.ND(:,2));
   minX = min(in_data.ND(:,2));
   maxY = max(in_data.ND(:,3));
   minY = min(in_data.ND(:,3));
   labx = (maxX / 6); laby = (maxY / 6);
if 0
   plot(in_data.ND(:,2),in_data.ND(:,3),'k.','MarkerSize',2); 
   axis equal; axis off; hold on;
   for i=1:size(in_data.EL)
      if in_data.EL(i,2)==9 
         node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
         node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
         node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
         plot3([in_data.ND(node1,2) in_data.ND(node2,2) in_data.ND(node3,2) in_data.ND(node1,2)], ...
            [in_data.ND(node1,3) in_data.ND(node2,3) in_data.ND(node3,3) in_data.ND(node1,3)],...
            [0 0 0 0],'k:');
      end;
   end;
end

SCz = labx*1.2; 
labz = SCz/6;

ND_d = in_data.ND;
ND_d(:,4) = (D(1:3:dof(1))'./max_D_z)*0.5*SCz;

%ND_d(:,2) = in_data.ND(:,2) + labx*D(1:2:dof(1))'./max_D_x;

plot3(ND_d(:,2),ND_d(:,3),ND_d(:,4),'r.','MarkerSize',2); 
axis equal; axis off; hold on; view(3);

for i=1:size(in_data.EL)
   if in_data.EL(i,2)==9  
      node1 = find(ND_d(:,1)==in_data.EL(i,3));
      node2 = find(ND_d(:,1)==in_data.EL(i,4));
      node3 = find(ND_d(:,1)==in_data.EL(i,5));
      plot3([ND_d(node1,2) ND_d(node2,2) ND_d(node3,2) ND_d(node1,2)], ...
         [ND_d(node1,3) ND_d(node2,3) ND_d(node3,3) ND_d(node1,3)], ...
         [ND_d(node1,4) ND_d(node2,4) ND_d(node3,4) ND_d(node1,4)],'r-');
   end;
end;

if 0

if NF > 100


for i=1:size(in_data.CON)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
   if in_data.CON(i,3)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
         [in_data.ND(node_i,3) in_data.ND(node_i,3)], [0 0],'b-','LineWidth',3); hold on;
   end;
   if in_data.CON(i,4)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
         [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby], [0 0],'b-','LineWidth',3); hold on;
   end;
   if in_data.CON(i,2)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
         [in_data.ND(node_i,3) in_data.ND(node_i,3)], [0 labz],'b-','LineWidth',3); hold on;
   end;
end;

end;
end;

% ===========================================================================END
axis([(-1.1*minX) (1.1*maxX) (-1.1*minY) (1.1*maxY) (-SCz)    (SCz)]);
end;

