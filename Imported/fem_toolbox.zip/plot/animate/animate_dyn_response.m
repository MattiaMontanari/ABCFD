function animate_dyn_response (resp,in_data)



[dofN,EL_TYPE] = type_of_elem (in_data);

switch EL_TYPE
    case {4,5,51}
        animate_response_tri(resp,in_data); %   
    case 9
        animate_bending_tri(resp,in_data);  %   
    case 3
        animate_3D_frame (resp,in_data);    %   
    case 31
        animate_3D_truss (resp,in_data);    %   
    case 6
        animate_3D_brick (resp,in_data);    %   
    case 10
        animate_3D_tetrah (resp,in_data);   %   
    case {0,1,2}
        animate_2D_frame(resp,in_data);     %   
end
