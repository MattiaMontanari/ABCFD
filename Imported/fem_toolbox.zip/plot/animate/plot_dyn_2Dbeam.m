function plot_dyn_2Dbeam (in_data,D,ind,dof, XXX,YYY, NF)

% plot 2D-FRAME dynamic displacements



dof = size(in_data.ND,1)*3;
figure(NF)
plot(in_data.ND(:,2),in_data.ND(:,3),'k.');
axis equal; axis off; hold on; view(2);
title('Displacements from static loads');
for i=1:size(in_data.EL)
   node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
   node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
   plot([in_data.ND(node1,2) in_data.ND(node2,2)], [in_data.ND(node1,3) in_data.ND(node2,3)],'k-','LineWidth',1);
end;

maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
labx = (maxX / 6); laby = (maxY / 6);
labx = min([labx laby]); laby = labx;

deN = max([XXX  YYY]);
dx = labx *D(1:3:dof(1)) /deN;
dy = laby *D(2:3:dof(1)) /deN;

plot(in_data.ND(:,2)+dx',in_data.ND(:,3)+dy','r.'); hold on;
ND_d = in_data.ND;
ND_d(:,2) = in_data.ND(:,2)+dx';
ND_d(:,3) = in_data.ND(:,3)+dy';
for i=1:size(in_data.EL)
   node1 = find(ND_d(:,1)==in_data.EL(i,3));
   node2 = find(ND_d(:,1)==in_data.EL(i,4));
   plot([ND_d(node1,2) ND_d(node2,2)], [ND_d(node1,3) ND_d(node2,3)],'r-');
end;

if 0
maxX = max(in_data.ND(:,2));
maxY = max(in_data.ND(:,3));
labx = (maxX / 10); laby = (maxY / 10);
for i=1:size(in_data.LOAD_)
   node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],'r-',...
         'LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],'r-',...
         'LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],'r-',...
         'LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],'r-',...
         'LineWidth',3); hold on;
   end;
end;

for i=1:size(in_data.CON)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
   if in_data.CON(i,2)==0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],'b-',...
         'LineWidth',3); hold on;
   end;
   if in_data.CON(i,3)==0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],'b-',...
         'LineWidth',3); hold on;
   end;
   if in_data.CON(i,4)==0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],'bs',...
         'LineWidth',3); hold on;
   end;
end;

end; 
axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby)]);
