function plot_deform_tri ( in_data, D, ind, dof, max_D_x, max_D_y,  NF) 


   figure(NF);

   maxX = max(in_data.ND(:,2));  minX = min(in_data.ND(:,2));
   maxY = max(in_data.ND(:,3));  minY = min(in_data.ND(:,3));
   labx = (maxX / 22); laby = (maxY / 22);
   labx = min([labx laby]); laby = labx;
   
   if 0 % block out ++++++++++++++++++
   MAX_SIG = (SIGsys(1:3:length(SIGsys))+SIGsys(2:3:length(SIGsys))).*0.5 +...
      sqrt((SIGsys(1:3:length(SIGsys))-SIGsys(2:3:length(SIGsys))).^2 +...
      SIGsys(3:3:length(SIGsys)).^2.*4);
   
   maxSIGmax = max(MAX_SIG);
   minSIGmax = min(MAX_SIG);


   if in_data.EL(1,2)==4  
       % plot triangles ------------------------------------
       plot(in_data.ND(:,2),in_data.ND(:,3),'k.');
       axis equal; axis off; hold on;
       yy = 0.8;
       for i=1:size(in_data.EL)
           % yy = (MAX_SIG(i) - minSIGmax)*1/(maxSIGmax - minSIGmax); 
           node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
           node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
           node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
           fill([in_data.ND(node1,2) in_data.ND(node2,2) in_data.ND(node3,2) in_data.ND(node1,2)], ...
               [in_data.ND(node1,3) in_data.ND(node2,3) in_data.ND(node3,3) in_data.ND(node1,3)],[yy yy yy]);
       end
   end;
   
   if in_data.EL(1,2)==5 | in_data.EL(1,2)==51  
       plot(in_data.ND(:,2),in_data.ND(:,3),'k.');
       axis equal; axis off; hold on; hold on;
       yy = 0.8;
       for i=1:size(in_data.EL)           
           node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
           node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
           node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
           node4 = find(in_data.ND(:,1)==in_data.EL(i,6));
           fill([in_data.ND(node1,2) in_data.ND(node2,2) in_data.ND(node3,2) ...
                   in_data.ND(node4,2) in_data.ND(node1,2)],...
               [in_data.ND(node1,3) in_data.ND(node2,3) in_data.ND(node3,3) in_data.ND(node4,3)...
                   in_data.ND(node1,3)],[yy yy yy]);
       end;
   end;
   end;% +++++++++++++++++++++++++++++++++   
   if 0 % block out +++++++++++++++++++++++++++++++++++++++++++++++++++
   % plot lines/directions of MAX stresses -------------
   for i=1:size(in_data.EL)
      yy = (MAX_SIG(i) - minSIGmax)*1/(maxSIGmax - minSIGmax); 
      node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
      node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
      node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
      Xi = [1 1 1; in_data.ND(node1,2) in_data.ND(node2,2) in_data.ND(node3,2); ...
            in_data.ND(node1,3) in_data.ND(node2,3) in_data.ND(node3,3)]*[1/3; 1/3; 1/3];
      angle_max = 0.5*atan(2*(SIGsys(i*3))/(SIGsys(i*3-2)-SIGsys(i*3-1)));
      vv = (SIGsys(i*3-2)) - (SIGsys(i*3-1));     
      yi = abs(cos(angle_max)*yy*laby);
      xi = abs(sin(angle_max)*yy*labx);
      angle_max  = angle_max*360/(2*pi);          
      if vv>0 txy=xi*laby/labx; xi=yi*labx/laby; yi=txy; end;
      
      if MAX_SIG(i)>0  cv='b-'; else cv='r-'; end;
      
      
      if vv<0 & angle_max>0  plot([Xi(2)-0.5*xi Xi(2)+0.5*xi],...
            [Xi(3)+0.5*yi Xi(3)-0.5*yi],cv,'LineWidth',2);
      end;
      if vv<0 & angle_max<0  plot([Xi(2)+0.5*xi Xi(2)-0.5*xi],...
            [Xi(3)+0.5*yi Xi(3)-0.5*yi],cv,'LineWidth',2); 
      end;
      
      if vv>0 & angle_max>0  plot([Xi(2)+0.5*xi Xi(2)-0.5*xi],...
            [Xi(3)+0.5*yi Xi(3)-0.5*yi],cv,'LineWidth',2); 
      end;
      if vv>0 & angle_max<0  plot([Xi(2)-0.5*xi Xi(2)+0.5*xi],...
            [Xi(3)+0.5*yi Xi(3)-0.5*yi],cv,'LineWidth',2);
      end;
      
   end;
   title('Stress field - MAX (blue - tension)');
   fg = ['max: ' num2str(maxSIGmax) '    ' 'min: ' num2str(minSIGmax)];
   xlabel(fg);
 end;% +++++++++++++++++++++++++++++++++++++++++++++++++


ND_d = in_data.ND;
deN = max([max_D_x  max_D_y]);
ND_d(:,2) = in_data.ND(:,2) + labx*D(1:2:dof(1))'./deN;
ND_d(:,3) = in_data.ND(:,3) + laby*D(2:2:dof(1))'./deN;


if in_data.EL(1,2)==4  % "4" - CST element (triangle) 
    plot(ND_d(:,2),ND_d(:,3),'r.','Markersize',5);
    axis equal; axis off; hold on;
    
    if 1 % BLOCK OFF ZZZZ
    for i=1:size(in_data.EL)
        node1 = find(ND_d(:,1)==in_data.EL(i,3));
        node2 = find(ND_d(:,1)==in_data.EL(i,4));
        node3 = find(ND_d(:,1)==in_data.EL(i,5));
        plot([ND_d(node1,2) ND_d(node2,2) ND_d(node3,2) ND_d(node1,2)], ...
            [ND_d(node1,3) ND_d(node2,3) ND_d(node3,3) ND_d(node1,3)],'r-');
    end;
    end  % END OF BLOCK OFF ZZZZ
end;

if in_data.EL(1,2)==5 | in_data.EL(1,2)==51
    plot(ND_d(:,2),ND_d(:,3),'r.');
    axis equal; axis off; hold on;
    for i=1:size(in_data.EL)           
        node1 = find(ND_d(:,1)==in_data.EL(i,3));
        node2 = find(ND_d(:,1)==in_data.EL(i,4));
        node3 = find(ND_d(:,1)==in_data.EL(i,5));
        node4 = find(ND_d(:,1)==in_data.EL(i,6));
        plot([ND_d(node1,2) ND_d(node2,2) ND_d(node3,2) ...
                ND_d(node4,2) ND_d(node1,2)],...
            [ND_d(node1,3) ND_d(node2,3) ND_d(node3,3) ND_d(node4,3)...
                ND_d(node1,3)],'r-');
    end
end

% ==============================================================
if 0 % START XX
for i=1:size(in_data.CON)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
 %  if in_data.CON(i,2)==0
 %     plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
 %        [in_data.ND(node_i,3) in_data.ND(node_i,3)],'b-','LineWidth',3); hold on;
 %  end;
 %  if in_data.CON(i,3)==0
 %     plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
 %        [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],'b-','LineWidth',3); hold on;
 %  end;
end;
end; % END OF XX
axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby)]);

hold off;
% ===========================================================================END
