% animate_response_tri.m    
function animate_response_tri (resp,in_data);


dofN = 2;   
dof_ = size(in_data.ND)*dofN;
warning off;
    XXX = max(max(abs( resp.dynamic.dva(:,1:2:dof_))));
    YYY = max(max(abs( resp.dynamic.dva(:,2:2:dof_))));


    
for k=1:size(resp.dynamic.dva,1)
%    if k<2 SIGsys_dyn = CST_CSQ_stress (EL, ND, resp.DYN_D(k,:).*5e3,E, h, miu); end;% stress at this time
    plot_deform_tri( in_data, resp.dynamic.dva(k,1:dof_), k, dof_, XXX, YYY, 2);
    
    jo = num2str(in_data.dynam.delta_tm*k); jo = strcat(jo, '  s');
    title(jo); hold off;
    pause(0.00001);

    if k<100 A='a'; end; if k<200 & k>=100 A='b'; end;
    if k<300 & k>=200 A='c'; end;
    eXt='.jpg'; B=strcat(A,int2str(k),eXt);
end


warning on;

