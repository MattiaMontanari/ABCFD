function animate_3D_frame (resp,in_data)

dofN = 6;   
dof_ = size(in_data.ND)*dofN;
warning off;
XXX = max(max(abs( resp.dynamic.dva(:,1:dofN:dof_))));
YYY = max(max(abs( resp.dynamic.dva(:,2:dofN:dof_))));
ZZZ = max(max(abs( resp.dynamic.dva(:,3:dofN:dof_))));

for k=1:size(resp.dynamic.dva,1)
    plot_dyn_3Dframe ( in_data, resp.dynamic.dva(k,1:dof_), k, dof_, XXX,YYY,ZZZ, 110) ;
    jo = num2str(in_data.dynam.delta_tm*k); jo = strcat(jo, '  s'); 
    title(jo); hold off;
    pause(.001);
    
    if k<100 A='a'; end; if k<200 & k>=100 A='b'; end;
    if k<300 & k>=200 A='c'; end;
    eXt='.jpg'; B=strcat(A,int2str(k),eXt);
end;
