function animate_mode_shape_2( in_data, obj, L, modeN, showLines )


[E_Vec,wn] = eigFEM_s (obj.Ksys.Kgl(L,L), obj.M(L,L), modeN);
D          = zeros(length(obj.M),1);
D(L,:)     = E_Vec(:, size(E_Vec,2)-modeN+1);
D          = D';
wn         = wn(size(E_Vec,2)-modeN+1);
dof        = size(obj.M);


figure(100021);
clf;

if in_data.EL(1,2)==9
    dof_per_node = 3;
    maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
    maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
    labx = (maxX / 6); laby =  (maxY / 6);
    labx = min(labx,laby); laby = labx;
    SCz = labx*1.2;
    labz = SCz/2;

    max_D_z = max(abs(D(1:3:dof(1)))); 
    ND_d = in_data.ND;
    ND_d(:,4) = (D(1:3:dof(1))'./max_D_z)*0.5*SCz;
end;

if in_data.EL(1,2)==0 | in_data.EL(1,2)==1 | in_data.EL(1,2)==2
    n_dof_node = 3;
    maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
    maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
    labx = (maxX / 6); laby = (maxY / 6);
    labx = min([labx laby]); laby = labx;
    max_D_x = max(abs(D(1:n_dof_node:dof(1))));
    max_D_y = max(abs(D(2:n_dof_node:dof(1))));
    ND_d = in_data.ND;
    deN = max([max_D_x  max_D_y]);
    ND_d(:,2) = in_data.ND(:,2)+(D(1:n_dof_node:dof(1))'./deN)*.5*labx;
    ND_d(:,3) = in_data.ND(:,3)+(D(2:n_dof_node:dof(1))'./deN)*.5*laby;
end;
if in_data.EL(1,2)==4 | in_data.EL(1,2)==5 | in_data.EL(1,2)==51
    n_dof_node = 2;
    maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
    maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
    labx = (maxX / 12); laby = (maxY / 12);
     labx = min([labx laby]); laby = labx;
    max_D_x = max(abs(D(1:n_dof_node:dof(1))));
    max_D_y = max(abs(D(n_dof_node:n_dof_node:dof(1))));
    ND_d = in_data.ND;
    deN = max([max_D_x  max_D_y]);
    ND_d(:,2) = in_data.ND(:,2)+(D(1:n_dof_node:dof(1))'./deN)*1.5*labx;
    ND_d(:,3) = in_data.ND(:,3)+(D(n_dof_node:n_dof_node:dof(1))'./deN)*1.5*laby;
end;
if in_data.EL(1,2)==3
    n_dof_node = 6;
    maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
    maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
    maxZ = max(in_data.ND(:,4)); minZ = min(in_data.ND(:,4));
    labx = (maxX / 6); laby = (maxY / 6); labz = (maxZ / 6);
    labx = min([labx laby labz]); laby = labx;  labz=labx;
    max_D_x = max(abs(D(1:n_dof_node:dof(1))));
    max_D_y = max(abs(D(2:n_dof_node:dof(1))));
    max_D_z = max(abs(D(3:n_dof_node:dof(1))));
    ND_d = in_data.ND;
    deN = max([max_D_x  max_D_y  max_D_z]);
    ND_d(:,2) = in_data.ND(:,2)+(D(1:n_dof_node:dof(1))'./deN)*.5*labx;
    ND_d(:,3) = in_data.ND(:,3)+(D(2:n_dof_node:dof(1))'./deN)*.5*laby;
    ND_d(:,4) = in_data.ND(:,4)+(D(3:n_dof_node:dof(1))'./deN)*.5*labz;
end;
if in_data.EL(1,2)==31
    n_dof_node = 3;
    maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
    maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
    maxZ = max(in_data.ND(:,4)); minZ = min(in_data.ND(:,4));
    labx = (maxX / 6); laby = (maxY / 6); labz = (maxZ / 6);
    labx = min([labx laby labz]); laby = labx;  labz=labx;
    max_D_x = max(abs(D(1:n_dof_node:dof(1))));
    max_D_y = max(abs(D(2:n_dof_node:dof(1))));
    max_D_z = max(abs(D(3:n_dof_node:dof(1))));
    ND_d = in_data.ND;
    deN = max([max_D_x  max_D_y  max_D_z]);
    ND_d(:,2) = in_data.ND(:,2)+(D(1:n_dof_node:dof(1))'./deN)*.5*labx;
    ND_d(:,3) = in_data.ND(:,3)+(D(2:n_dof_node:dof(1))'./deN)*.5*laby;
    ND_d(:,4) = in_data.ND(:,4)+(D(3:n_dof_node:dof(1))'./deN)*.5*labz;
end;
if in_data.EL(1,2)==6 | in_data.EL(1,2)==10
    n_dof_node = 3;
    maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
    maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
    maxZ = max(in_data.ND(:,4)); minZ = min(in_data.ND(:,4));
    labx = (maxX / 2); laby = (maxY / 2); labz = (maxZ / 2);
    labx = max([labx laby labz]); laby = labx;  labz=labx;
    max_D_x = max(abs(D(1:n_dof_node:dof(1))));
    max_D_y = max(abs(D(2:n_dof_node:dof(1))));
    max_D_z = max(abs(D(3:n_dof_node:dof(1))));
    ND_d = in_data.ND;
    deN = max([max_D_x  max_D_y  max_D_z]);
    ND_d(:,2) = in_data.ND(:,2)+(D(1:n_dof_node:dof(1))'./deN)*0.25*labx;
    ND_d(:,3) = in_data.ND(:,3)+(D(2:n_dof_node:dof(1))'./deN)*0.25*labx;
    ND_d(:,4) = in_data.ND(:,4)+(D(3:n_dof_node:dof(1))'./deN)*0.25*labx;
end;


if in_data.EL(1,2)==0 | in_data.EL(1,2)==1 | in_data.EL(1,2)==2
    plot(ND_d(:,2),ND_d(:,3),'r.'); hold on;
end;

if in_data.EL(1,2)==4 | in_data.EL(1,2)==5 | in_data.EL(1,2)==51
    plot(ND_d(:,2),ND_d(:,3),'r.'); hold on;
end;

if in_data.EL(1,2)==3 | in_data.EL(1,2)==6 | in_data.EL(1,2)==31 | in_data.EL(1,2)==10
    %plot3(ND_d(:,2),ND_d(:,3),ND_d(:,4),'r.'); hold on;
end;


% -------------------------------------------------------------------------
if showLines
for i=1:size(in_data.EL,1)
    if in_data.EL(i,2)==9
        % plot3(ND_d(:,2),ND_d(:,3),ND_d(:,4),'r.');
        node1 = find(ND_d(:,1)==in_data.EL(i,3));
        node2 = find(ND_d(:,1)==in_data.EL(i,4));
        node3 = find(ND_d(:,1)==in_data.EL(i,5));
        plot3([ND_d(node1,2) ND_d(node2,2) ND_d(node3,2) ND_d(node1,2)], ...
              [ND_d(node1,3) ND_d(node2,3) ND_d(node3,3) ND_d(node1,3)], ...
              [ND_d(node1,4) ND_d(node2,4) ND_d(node3,4) ND_d(node1,4)],'r-');
        axis equal; axis off; view(3); hold on;
        axis([(-1.1*minX) (1.1*maxX) (-1.1*minY) (1.1*maxY) (-SCz)    (SCz)]);
    end;
    
    
    if in_data.EL(i,2)==0 | in_data.EL(i,2)==1 | in_data.EL(i,2)==2
        node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
        node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
        plot([ND_d(node1,2) ND_d(node2,2)], ...
             [ND_d(node1,3) ND_d(node2,3)],'r-');
        axis equal; axis off;
        axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby)]);
    end;    
    if in_data.EL(i,2)==4
        node1 = find(ND_d(:,1)==in_data.EL(i,3));
        node2 = find(ND_d(:,1)==in_data.EL(i,4));
        node3 = find(ND_d(:,1)==in_data.EL(i,5));
        plot([ND_d(node1,2) ND_d(node2,2) ND_d(node3,2) ND_d(node1,2)], ...
            [ND_d(node1,3) ND_d(node2,3) ND_d(node3,3) ND_d(node1,3)],'r-');
        axis equal; axis off;
        axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby) ]);
    end;
    if in_data.EL(i,2)==5 | in_data.EL(1,2)==51
        node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
        node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
        node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
        node4 = find(in_data.ND(:,1)==in_data.EL(i,6));
        plot([ND_d(node1,2) ND_d(node2,2) ND_d(node3,2) ND_d(node4,2) ND_d(node1,2)],...
             [ND_d(node1,3) ND_d(node2,3) ND_d(node3,3) ND_d(node4,3) ND_d(node1,3)],'r-');
        axis equal; axis off;
        axis([(minX-2*labx) (maxX+2*labx) (minY-2*laby) (maxY+2*laby)]);
    end;
    if in_data.EL(i,2)==3 | in_data.EL(i,2)==31
        node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
        node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
        plot3([ND_d(node1,2) ND_d(node2,2)], ...
              [ND_d(node1,3) ND_d(node2,3)],[ND_d(node1,4) ND_d(node2,4)],'r-');
        axis equal; axis off;
        axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby) (minZ-labz)    (maxZ+labz)]);
    end;
end;

end;
axis equal; axis off;
% -------------------------------------------------------------------------

if in_data.EL(1,2)==6
    [qu] = surfbrick(in_data.ND(:,2:end),in_data.EL(:,3:10));
    ndPlot = unique(qu);
    tot_d = sqrt( (D(1:n_dof_node:dof(1))).^2 + ...
        (D(2:n_dof_node:dof(1))).^2 + (D(3:n_dof_node:dof(1))).^2 );
    plot3(in_data.ND(ndPlot,2),in_data.ND(ndPlot,3),in_data.ND(ndPlot,4),'b.','MarkerSize',2);
    for i=1:size(qu,1)
        patch([ND_d(qu(i,1),2) ND_d(qu(i,2),2) ND_d(qu(i,3),2) ND_d(qu(i,4),2)], ...
              [ND_d(qu(i,1),3) ND_d(qu(i,2),3) ND_d(qu(i,3),3) ND_d(qu(i,4),3)], ...
              [ND_d(qu(i,1),4) ND_d(qu(i,2),4) ND_d(qu(i,3),4) ND_d(qu(i,4),4)],[tot_d(qu(i,1)) tot_d(qu(i,2)) tot_d(qu(i,3)) tot_d(qu(i,4))]);
    end
    axis equal; axis off;
end


if in_data.EL(1,2)==10
    tri2=surftri(in_data.ND(:,2:4),in_data.EL(:,3:6));
    tot_d = sqrt( (D(1:n_dof_node:dof(1))).^2 + ...
        (D(2:n_dof_node:dof(1))).^2 + (D(3:n_dof_node:dof(1))).^2 );
    tot_d = tot_d./max(tot_d);
    trimesh(tri2,ND_d(:,2),ND_d(:,3),ND_d(:,4),'CData',[tot_d'],'facecolor','interp','edgecolor','y');
    hold on;
    trimesh(tri2,in_data.ND(:,2),in_data.ND(:,3),in_data.ND(:,4),'facecolor','none','edgecolor','k');
    axis equal;
    axis off;
    hold on;
end






% -------------------------------------------------------------------------
if showLines
if in_data.EL(1,2)==4 | in_data.EL(1,2)==5 | in_data.EL(1,2)==51
    for i=1:size(in_data.CON)
        node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
        if in_data.CON(i,2)==0
            plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx*0.5],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)],'b-','LineWidth',3); hold on;
            plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx*0.5],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)],'b-','LineWidth',3); hold on;
        end;
        if in_data.CON(i,3)==0
            plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby*0.5],'b-','LineWidth',3); hold on;
            plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby*0.5],'b-','LineWidth',3); hold on;
        end;
    end;
    axis equal; axis off;
    view(2);
    %axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby) ]);
    hold off;
end;

if in_data.EL(1,2)==3
    maxZ = max(in_data.ND(:,4));
    labz = (maxZ / 8);
    for i=1:size(in_data.CON)
        node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
        if in_data.CON(i,2)==0
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)],'b-','LineWidth',3); hold on;
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)],'b-','LineWidth',3); hold on;
        end;
        if in_data.CON(i,3)==0
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)],'b-','LineWidth',3); hold on;
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)],'b-','LineWidth',3); hold on;
        end;
        if in_data.CON(i,4)==0
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'b-','LineWidth',3); hold on;
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'b-','LineWidth',3); hold on;
        end;
    end;
    view(3);
    hold off;
end;

if in_data.EL(1,2)==0 | in_data.EL(i,2)==1 | in_data.EL(i,2)==2
    for i=1:size(in_data.CON)
        node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
        if in_data.CON(i,2)==0
            plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],'b-',...
                'LineWidth',3); hold on;
        end;
        if in_data.CON(i,3)==0
            plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],'b-',...
                'LineWidth',3); hold on;
        end;
        if in_data.CON(i,4)==0
            plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],'bs',...
                'LineWidth',3); hold on;
        end;
    end;
    view(2);
    hold off;
end;

if in_data.EL(1,2)==10
    maxX = max(in_data.ND(:,2));
    labx = (maxX / 12);
    maxY = max(in_data.ND(:,3));
    laby = (maxY / 12);
    maxZ = max(in_data.ND(:,4));
    labz = (maxZ / 12);
    labx = min([labx laby labz]); laby = labx;  labz=labx;
    for i=1:size(in_data.CON)
        node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
        if in_data.CON(i,2)==0
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)],'k-','LineWidth',3); hold on;
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)],'k-','LineWidth',3); hold on;
        end;
        if in_data.CON(i,3)==0
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)],'k-','LineWidth',3); hold on;
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)],'k-','LineWidth',3); hold on;
        end;
        if in_data.CON(i,4)==0
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'k-','LineWidth',3); hold on;
            plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                [in_data.ND(node_i,3) in_data.ND(node_i,3)],...
                [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'k-','LineWidth',3); hold on;
        end;
    end;
    hold off;
end;
end
%--------------------------------------------------------------------------

title(['Mode: ' num2str(modeN) '. Frequency: ' num2str(wn/(2*pi)) ' [Hz]']);
