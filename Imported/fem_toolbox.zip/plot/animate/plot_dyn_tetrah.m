function  plot_dyn_tetrah ( in_data, D, ind, dof_, XXX,YYY,ZZZ, NF) 

% =============================================================================

figure(NF);

maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
maxZ = max(in_data.ND(:,4)); minZ = min(in_data.ND(:,4));

labx = (maxX / 2); laby = (maxY / 2); labz = (maxZ / 2);
labx = min([labx laby labz]); laby = labx;  labz=labx;

deN = max([XXX  YYY  ZZZ]);
dx = labx *D(1:3:dof_(1)) /deN;
dy = laby *D(2:3:dof_(1)) /deN;
dz = labz *D(3:3:dof_(1)) /deN;

%===========================================================
switch 1
case {1}
    x_ind_z = find((in_data.ND(:,4))>0.99);
    dx_z = dx(x_ind_z); dy_z = dy(x_ind_z); dz_z = dz(x_ind_z);
    dz_z=dz_z.*10;
    pz=in_data.ND(x_ind_z,:);
    tr_ = delaunayn(pz(:,2:3));                   
    respFLD =  sqrt( dx_z.^2 + dy_z.^2 + dz_z.^2 );
    h10 =  trisurf(tr_,pz(:,2),pz(:,3),pz(:,4)+respFLD',respFLD);
    set(h10,'FaceLighting','phong');
    shading interp; 
    axis equal;  axis off;
    colormap(hsv);
    zoom(1.8); 
    view(-40,17);
    set(h10,'EdgeColor',[0.5 0.5 0.5]);
    caxis([ -.15 .15 ]);
    axis([-1 1 -1 1 0.8 1.4 ]);
    hold on;
case {2}
    x_ind = find(abs(in_data.ND(:,2))<0.1); % |X|<0.1
    dxx = dx(x_ind); dyy = dy(x_ind); dzz = dz(x_ind);
    pn=in_data.ND(x_ind,:);   % vertical plane nodes
    tr_ = delaunayn(pn(:,3:4));                  % vertical plane
    respFLD = sqrt( dxx.^2 + dyy.^2 + dzz.^2 );
    h12 =  trisurf(tr_, pn(:,2).*0,pn(:,3), pn(:,4)-0.01, respFLD);
    set(h12,'FaceLighting','phong');
    shading interp; axis equal; 
    colormap(hsv);
    caxis([ -.08 .08 ]);
    axis off; hidden on,
    view(-90,19)
    set(h12,'EdgeColor',[.6 .6 .7]);
    set(h10,'EdgeColor',[0.5 0.5 0.5]);
    axis([(minX) (maxX) (minY) (maxY) (minZ) (maxZ) ]);
case {3}
    x_ind_y = find(abs(in_data.ND(:,3))<0.1);
    dx_y = dx(x_ind_y); dy_y = dy(x_ind_y); dz_y = dz(x_ind_y);
    pn=in_data.ND(x_ind_y,:);   % vertical plane nodes
    tr_ = delaunayn(pn(:,2:2:4));                
    respFLD = sqrt( dx_y.^2 + dy_y.^2 + dz_y.^2 );
    h13 =  trisurf(tr_, pn(:,2),pn(:,3).*0, pn(:,4), respFLD);
    set(h13,'FaceLighting','phong');
    shading interp; axis equal; 
    colormap(hsv);
    caxis([ -.08 .08 ]);
    axis off; hidden on;
    view(-44,34)
    set(h13,'EdgeColor',[.6 .6 .7]);
    set(h12,'EdgeColor',[.6 .6 .7]);
    set(h10,'EdgeColor',[0.5 0.5 0.5]);
    axis([(minX) (maxX) (minY) (maxY) (minZ) (maxZ) ]);
case {4}
    dx=dx.*10;
    dy=dy.*10;
    dz=dz.*10;
    tri2=surftri(in_data.ND(:,2:4),in_data.EL(:,3:6));
    h5 = trimesh(tri2,in_data.ND(:,2)+dx',in_data.ND(:,3)+dy',in_data.ND(:,4)+dz',...
        'facecolor',[.6 .6 .8],'edgecolor','b');
    set(h5,'facecolor',[.5 .5 .5],'edgecolor','k');
    axis equal, axis off;
end




% ===========================================================================END
