function plot_dyn_brick ( in_data, D, ind, dof_, XXX,YYY,ZZZ, NF) 


figure(NF)

title('Displacements from static loads');

if 0
for i=1:size(in_data.EL)
    
    node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
    node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
    node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
    node4 = find(in_data.ND(:,1)==in_data.EL(i,6));
    node5 = find(in_data.ND(:,1)==in_data.EL(i,7));
    node6 = find(in_data.ND(:,1)==in_data.EL(i,8));
    node7 = find(in_data.ND(:,1)==in_data.EL(i,9));
    node8 = find(in_data.ND(:,1)==in_data.EL(i,10));
    
    plot3([in_data.ND(node1,2) in_data.ND(node2,2) in_data.ND(node3,2) in_data.ND(node4,2) in_data.ND(node1,2) ...
          in_data.ND(node5,2) in_data.ND(node6,2) in_data.ND(node7,2) in_data.ND(node8,2) in_data.ND(node5,2)],...
       [in_data.ND(node1,3) in_data.ND(node2,3) in_data.ND(node3,3) in_data.ND(node4,3) in_data.ND(node1,3) ...
          in_data.ND(node5,3) in_data.ND(node6,3) in_data.ND(node7,3) in_data.ND(node8,3) in_data.ND(node5,3)],...
       [in_data.ND(node1,4) in_data.ND(node2,4) in_data.ND(node3,4) in_data.ND(node4,4) in_data.ND(node1,4) ...
          in_data.ND(node5,4) in_data.ND(node6,4) in_data.ND(node7,4) in_data.ND(node8,4) in_data.ND(node5,4)],...
          'k:','LineWidth',1);    
    
    plot3([in_data.ND(node2,2) in_data.ND(node6,2) in_data.ND(node7,2) in_data.ND(node3,2) in_data.ND(node2,2) ...
          in_data.ND(node1,2) in_data.ND(node5,2) in_data.ND(node8,2) in_data.ND(node4,2) in_data.ND(node1,2)],...
       [in_data.ND(node2,3) in_data.ND(node6,3) in_data.ND(node7,3) in_data.ND(node3,3) in_data.ND(node2,3) ...
          in_data.ND(node1,3) in_data.ND(node5,3) in_data.ND(node8,3) in_data.ND(node4,3) in_data.ND(node1,3)],...
       [in_data.ND(node2,4) in_data.ND(node6,4) in_data.ND(node7,4) in_data.ND(node3,4) in_data.ND(node2,4) ...
         in_data.ND(node1,4) in_data.ND(node5,4) in_data.ND(node8,4) in_data.ND(node4,4) in_data.ND(node1,4)],...
         'k:','LineWidth',1);
      
 end;
 end; % end IF
 

maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
maxZ = max(in_data.ND(:,4)); minZ = min(in_data.ND(:,4));

labx = (maxX / 6); laby = (maxY / 6); labz = (maxZ / 6);
labx = min([labx laby labz]); laby = labx;  labz=labx;

deN = max([XXX  YYY  ZZZ]);
dx = labx *D(1:3:dof_(1)) /deN;
dy = laby *D(2:3:dof_(1)) /deN;
dz = labz *D(3:3:dof_(1)) /deN;

plot3(in_data.ND(:,2)+dx',in_data.ND(:,3)+dy', in_data.ND(:,4)+dz','r.'); 
axis equal; axis off; hold on; view(3);
ND_d = in_data.ND;
ND_d(:,2) = in_data.ND(:,2)+dx';
ND_d(:,3) = in_data.ND(:,3)+dy';
ND_d(:,4) = in_data.ND(:,4)+dz';

for i=1:size(in_data.EL)
    node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
    node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
    node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
    node4 = find(in_data.ND(:,1)==in_data.EL(i,6));
    node5 = find(in_data.ND(:,1)==in_data.EL(i,7));
    node6 = find(in_data.ND(:,1)==in_data.EL(i,8));
    node7 = find(in_data.ND(:,1)==in_data.EL(i,9));
    node8 = find(in_data.ND(:,1)==in_data.EL(i,10));
    
    plot3([ND_d(node1,2) ND_d(node2,2) ND_d(node3,2) ND_d(node4,2) ND_d(node1,2) ...
          ND_d(node5,2) ND_d(node6,2) ND_d(node7,2) ND_d(node8,2) ND_d(node5,2)],...
       [ND_d(node1,3) ND_d(node2,3) ND_d(node3,3) ND_d(node4,3) ND_d(node1,3) ...
          ND_d(node5,3) ND_d(node6,3) ND_d(node7,3) ND_d(node8,3) ND_d(node5,3)],...
       [ND_d(node1,4) ND_d(node2,4) ND_d(node3,4) ND_d(node4,4) ND_d(node1,4) ...
          ND_d(node5,4) ND_d(node6,4) ND_d(node7,4) ND_d(node8,4) ND_d(node5,4)],'r-');
    
    plot3([ND_d(node2,2) ND_d(node6,2) ND_d(node7,2) ND_d(node3,2) ND_d(node2,2) ...
          ND_d(node1,2) ND_d(node5,2) ND_d(node8,2) ND_d(node4,2) ND_d(node1,2)],...
       [ND_d(node2,3) ND_d(node6,3) ND_d(node7,3) ND_d(node3,3) ND_d(node2,3) ...
          ND_d(node1,3) ND_d(node5,3) ND_d(node8,3) ND_d(node4,3) ND_d(node1,3)],...
       [ND_d(node2,4) ND_d(node6,4) ND_d(node7,4) ND_d(node3,4) ND_d(node2,4) ...
          ND_d(node1,4) ND_d(node5,4) ND_d(node8,4) ND_d(node4,4) ND_d(node1,4)],'r-');
end;


if 0
   KL = size(in_data.EL);
   maxSmax = max(SIG_main(1:3:KL(1)));
   minSmax = min(SIG_main(1:3:KL(1)));
   for i=1:KL(1) 
      if in_data.EL(i,2)==6 
         yy = (SIG_main(i*3-2) - minSmax)*1/(maxSmax - minSmax); 
         SCALE = 6; 
         yy = abs(yy+0.001) * SCALE;
         
         node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
         node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
         node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
         node4 = find(in_data.ND(:,1)==in_data.EL(i,6));
         node5 = find(in_data.ND(:,1)==in_data.EL(i,7));
         node6 = find(in_data.ND(:,1)==in_data.EL(i,8));
         node7 = find(in_data.ND(:,1)==in_data.EL(i,9));
         node8 = find(in_data.ND(:,1)==in_data.EL(i,10));
         if SIG_main(i*3-2)>0 ff='r.'; else ff='b.'; end;
         
         plot3( (in_data.ND(node1,2)+ in_data.ND(node2,2)+ in_data.ND(node3,2)+ in_data.ND(node4,2)+ ...
             in_data.ND(node5,2)+in_data.ND(node6,2)+ in_data.ND(node7,2)+ in_data.ND(node8,2))/8, ...
             (in_data.ND(node1,3)+ in_data.ND(node2,3)+ in_data.ND(node3,3)+ in_data.ND(node4,3)+ ...
             in_data.ND(node5,3)+in_data.ND(node6,3)+ in_data.ND(node7,3)+ in_data.ND(node8,3))/8,...
             (in_data.ND(node1,4)+ in_data.ND(node2,4)+ in_data.ND(node3,4)+ in_data.ND(node4,4)+ ...
             in_data.ND(node5,4)+in_data.ND(node6,4)+ in_data.ND(node7,4)+ in_data.ND(node8,4))/8,...
             ff,'Linewidth',yy);
      end;
   end;

for i=1:size(in_data.LOAD_)
   node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)+labz],'r-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'r-','LineWidth',4); hold on;
   end;
end;


for i=1:size(in_data.CON)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
   if in_data.CON(i,2)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',3); hold on;
   end;
   if in_data.CON(i,3)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',3); hold on;
   end;
   if in_data.CON(i,4)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'g-','LineWidth',3); hold on;
   end;
   if in_data.CON(i,4)==0 | in_data.CON(i,5)==0 | in_data.CON(i,6)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'gs','LineWidth',3); hold on;
   end;
end;
end;  

axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby) (minZ-labz) (maxZ+labz)]);

