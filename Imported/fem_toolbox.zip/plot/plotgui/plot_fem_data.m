function plot_fem_data(in_data,PND)

% plot input object on GUI main form

if in_data.EL(1,2)==0 | in_data.EL(1,2)==1 | in_data.EL(1,2)==2 ...
        | in_data.EL(1,2)==31 dofN = 3; end;
if in_data.EL(1,2)==3 dofN = 6; end;        
if in_data.EL(1,2)==4 dofN = 2; end;        
if in_data.EL(1,2)==5 | in_data.EL(1,2)==51 dofN = 2; end;
if in_data.EL(1,2)==6 dofN = 3; end;    
if in_data.EL(1,2)==9 dofN = 3; end;    
if in_data.EL(1,2)==10 dofN = 3; end;   
if in_data.EL(1,2)==44 dofN = 1; end;   


dof_ = size(in_data.ND,1)*dofN;


if in_data.EL(1,2)==9
    plot_bend_data ( in_data, dof_, 120, PND); 
end;

if in_data.EL(1,2)==4  |  in_data.EL(1,2)==5 | in_data.EL(1,2)==51
    plot_CSTQ_input(  in_data, dof_, 110, PND );
end;  

if in_data.EL(1,2)==3 | in_data.EL(1,2)==31
        plot_3Dframe_input(in_data,PND); 
end;

if in_data.EL(1,2)==6 
    plot_input_brick (in_data, dof_,PND);
end;

if in_data.EL(1,2)==0 | in_data.EL(1,2)==1 | in_data.EL(1,2)==2
    plot_input_2dbeam (in_data,PND);
end;

if in_data.EL(1,2)==10
    plot_input_tetrah (in_data, dof_,PND);
end;
if in_data.EL(1,2)==44
    plot_heat_CST_input (in_data, dof_, 110, PND);
end;




% plot functions ----------------------------------------------------------
function plot_input_2dbeam (in_data,PND)
hold off;
maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
labx = (maxX / 9); laby = (maxY / 9);
labx = min([labx laby]); laby = labx;

xL = [0:0.05:1]';			
N  = length(xL);
oo = ones(N,1);

for i=1:size(in_data.LOAD_)
   node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],...
         'r-','LineWidth',2); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         'r-','LineWidth',3); hold on;
   end;
end;

for i=1:size(in_data.CON)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
   if in_data.CON(i,2)==0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,3)==0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         'gs','LineWidth',2); hold on;
   end;
end;
axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby)]); % plot scale

dof = size(in_data.ND,1)*3; % total dof
plot(in_data.ND(:,2),in_data.ND(:,3),'y.','Markersize',2);
axis equal; axis off; hold on;
for i=1:size(in_data.EL)
   node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
   node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
   % plot uniformly distributed load
   x1 = in_data.ND(node1,2);  y1 = in_data.ND(node1,3);
   x2 = in_data.ND(node2,2);  y2 = in_data.ND(node2,3);
   L = sqrt( (x2-x1)^2 + (y2-y1)^2 ) ;	      
   c = (x2-x1) / L;		
   s = (y2-y1) / L;		
   T = [ c s 0   0 0 0 ;	
        -s c 0   0 0 0 ;
         0 0 1   0 0 0 ;
         0 0 0   c s 0 ;
         0 0 0  -s c 0 ;
         0 0 0   0 0 1 ];
   v = zeros(6,1);     
   u = T*v;			
   ld = L + u(4) - u(1);

   x = u(1) + xL*ld;
   xd =  [ x  x.*0 ] * [ c s ; -s  c ];
   xn =  [ x ones(21,1)*labx*0.5 ] * [ c s ; -s  c ];
   if  isfield(in_data,'q')
       if in_data.q(i)~=0
           plot(x1+xn(:,1),y1+xn(:,2),'r:');
       end;
   end

   plot([in_data.ND(node1,2) in_data.ND(node2,2)], ...
       [in_data.ND(node1,3) in_data.ND(node2,3)],'Color',[0.4 0.1 0.7],'LineWidth',1);
   if PND == 1
       h=text(in_data.ND(node1,2) , in_data.ND(node1,3), num2str(node1)); 
       set(h,'FontSize',8); set(h,'Color','k');
       h=text(in_data.ND(node2,2) , in_data.ND(node2,3), num2str(node2)); 
       set(h,'FontSize',8); set(h,'Color','k');
       x1= (in_data.ND(node2,2)-in_data.ND(node1,2))/1.8 + in_data.ND(node1,2);
       y1= (in_data.ND(node2,3)-in_data.ND(node1,3))/1.8 + in_data.ND(node1,3);
       h=text(x1 , y1, num2str(in_data.EL(i,1))); set(h,'FontSize',6); set(h,'Color','m');
   end;
end;
h=title('Input model'); set(h,'FontSize',12);
rotate3d(gca); set(gcf,'Pointer','arrow');
hold off;

% -------------------------------------------------------------------------
function plot_bend_data ( in_data, dof, NF,PND) 

hold off;
if 1
   maxX = max(in_data.ND(:,2));
   minX = min(in_data.ND(:,2));
   maxY = max(in_data.ND(:,3));
   minY = min(in_data.ND(:,3));
   labx = (maxX / 15); laby = (maxY / 15);
   labx = min([labx laby]); laby = labx;
   
   SCz = 1; labz = SCz/4;
   
   if NF > 100
       for i=1:size(in_data.LOAD_)
           node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
           if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
               plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)],[0 0],'r-','LineWidth',2); hold on;
           end;
           if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
               plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)],[0 0],'r-','LineWidth',2); hold on;
           end;
           if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)>0
               plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],[0 0],'r-','LineWidth',2); hold on;
           end;
           if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)<0
               plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],[0 0],'r-','LineWidth',2); hold on;
           end;
           if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
               plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)],[0 labz],'r-','LineWidth',2); hold on;
           end;
           if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
               plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)],[0 -labz],'r-','LineWidth',2); hold on;
           end;
       end;

       for i=1:size(in_data.CON)
           node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
           if in_data.CON(i,3)==0
               plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)], [0 0],'g-','LineWidth',2); hold on;
           end;
           if in_data.CON(i,4)==0
               plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby], [0 0],'g-','LineWidth',2); hold on;
           end;
           if in_data.CON(i,2)==0
               plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)], [0 labz],'g-','LineWidth',2); hold on;
           end;
       end;
   end; % -- end if NF > 100

   plot(in_data.ND(:,2),in_data.ND(:,3),'y.','Markersize',2);
   axis equal; axis off; view(3); hold on;
   for i=1:size(in_data.EL)
      if in_data.EL(i,2)==9  % "9" - BCIZ element (bending triangle) 
         node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
         node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
         node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
         plot3([in_data.ND(node1,2) in_data.ND(node2,2) in_data.ND(node3,2) in_data.ND(node1,2)], ...
            [in_data.ND(node1,3) in_data.ND(node2,3) in_data.ND(node3,3) in_data.ND(node1,3)],...
            [0 0 0 0],'Color',[0.4 0.1 0.7],'LineWidth',1);
        if PND == 1
            h=text(in_data.ND(node1,2) , in_data.ND(node1,3), 0, num2str(node1)); set(h,'FontSize',8); 
            set(h,'Color','k');
            h=text(in_data.ND(node2,2) , in_data.ND(node2,3), 0, num2str(node2)); set(h,'FontSize',8); 
            set(h,'Color','k');
            h=text(in_data.ND(node3,2) , in_data.ND(node3,3), 0, num2str(node3)); set(h,'FontSize',8); 
            set(h,'Color','k');
            x1= in_data.ND(node1,2)/3  +  in_data.ND(node2,2)/3 +  in_data.ND(node3,2)/3;
            y1= in_data.ND(node1,3)/3  +  in_data.ND(node2,3)/3 +  in_data.ND(node3,3)/3;
            h=text(x1 , y1, 0, num2str(in_data.EL(i,1))); set(h,'FontSize',6); set(h,'Color','m');
        end;
      end;
   end;
end;
% =========END
axis([(-1.1*minX) (1.1*maxX) (-1.1*minY) (1.1*maxY) (-SCz)    (SCz)]);
h=title('Input model'); set(h,'FontSize',12);
rotate3d(gca); set(gcf,'Pointer','arrow');
hold off;



% --------------------------------------------------------------------------------
function plot_CSTQ_input ( in_data, dof, NF, PND) 

hold off;
if 1
   maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
   maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
   labx = abs(maxX / 15); laby = abs(maxY / 15);
   labx = max([labx laby]); laby = labx;


   if NF > 100

       % hold on
       for i=1:size(in_data.LOAD_)
           node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
           if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)],'r-','LineWidth',3); hold on;
           end;
           if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)],'r-','LineWidth',3);hold on;
           end;
           if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],'r-','LineWidth',3);hold on;
           end;
           if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],'r-','LineWidth',3);hold on;
           end;
       end;
  

       for i=1:size(in_data.CON)
           node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
           if in_data.CON(i,2)==0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)],'g-','LineWidth',2.5);
           end;
           if in_data.CON(i,3)==0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],'g-','LineWidth',2.5);
           end;
       end;
   end;
   
   
   plot(in_data.ND(:,2),in_data.ND(:,3),'y.','MarkerSize',2);
   axis equal; axis off; view(2); hold on;
   for i=1:size(in_data.EL)
      yy = 0.9;
      if in_data.EL(i,2)==4
         node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
         node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
         node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
         plot([in_data.ND(node1,2) in_data.ND(node2,2) in_data.ND(node3,2) in_data.ND(node1,2)], ...
            [in_data.ND(node1,3) in_data.ND(node2,3) in_data.ND(node3,3) in_data.ND(node1,3)],...
            'Color',[0.4 0.1 0.7],'LineWidth',.1);
        if PND == 1
            h=text(in_data.ND(node1,2) , in_data.ND(node1,3), 0, num2str(node1)); set(h,'FontSize',8); 
            set(h,'Color','k');
            h=text(in_data.ND(node2,2) , in_data.ND(node2,3), 0, num2str(node2)); set(h,'FontSize',8); 
            set(h,'Color','k');
            h=text(in_data.ND(node3,2) , in_data.ND(node3,3), 0, num2str(node3)); set(h,'FontSize',8); 
            set(h,'Color','k');
            x1= in_data.ND(node1,2)/3  +  in_data.ND(node2,2)/3 +  in_data.ND(node3,2)/3;
            y1= in_data.ND(node1,3)/3  +  in_data.ND(node2,3)/3 +  in_data.ND(node3,3)/3;
            h=text(x1 , y1, num2str(in_data.EL(i,1))); set(h,'FontSize',6); set(h,'Color','m');
        end;
      end;
      if in_data.EL(i,2)==5 | in_data.EL(i,2)==51
         node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
         node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
         node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
         node4 = find(in_data.ND(:,1)==in_data.EL(i,6));
         plot([in_data.ND(node1,2) in_data.ND(node2,2) in_data.ND(node3,2) ...
                 in_data.ND(node4,2) in_data.ND(node1,2)],...
             [in_data.ND(node1,3) in_data.ND(node2,3) in_data.ND(node3,3) in_data.ND(node4,3)...
                 in_data.ND(node1,3)],'Color',[0.4 0.1 0.7],'LineWidth',.1);  % [yy yy yy] 
         if PND == 1
             h=text(in_data.ND(node1,2) , in_data.ND(node1,3), 0, num2str(node1)); set(h,'FontSize',8); 
             set(h,'Color','k');
             h=text(in_data.ND(node2,2) , in_data.ND(node2,3), 0, num2str(node2)); set(h,'FontSize',8); 
             set(h,'Color','k');
             h=text(in_data.ND(node3,2) , in_data.ND(node3,3), 0, num2str(node3)); set(h,'FontSize',8); 
             set(h,'Color','k');
             h=text(in_data.ND(node4,2) , in_data.ND(node4,3), 0, num2str(node4)); set(h,'FontSize',8); 
             set(h,'Color','k');
             x1= in_data.ND(node1,2)/4  +  in_data.ND(node2,2)/4 +  in_data.ND(node3,2)/4  + in_data.ND(node4,2)/4;
             y1= in_data.ND(node1,3)/4  +  in_data.ND(node2,3)/4 +  in_data.ND(node3,3)/4  + in_data.ND(node4,3)/4;
             h=text(x1 , y1, num2str(in_data.EL(i,1))); set(h,'FontSize',6); set(h,'Color','m');
         end;
     end;
 end;

 h=title('Input model'); set(h,'FontSize',12);
 axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby)]); drawnow
 rotate3d(gca); set(gcf,'Pointer','arrow');
 hold off;
 
 % =======END
end


% ------------------------------------------------------------------------
function plot_3Dframe_input(in_data,PND)

hold off;

plot3(in_data.ND(:,2),in_data.ND(:,3),in_data.ND(:,4),'y.','MarkerSize',2);
axis equal; axis off; view(3); hold on;
h=title('Input model'); set(h,'FontSize',12);
for i=1:size(in_data.EL)
   node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
   node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
   plot3([in_data.ND(node1,2) in_data.ND(node2,2)], ...
      [in_data.ND(node1,3) in_data.ND(node2,3)],[in_data.ND(node1,4) in_data.ND(node2,4)],'Color',[0.4 0.1 0.7],'LineWidth',1);
  if PND == 1
      h=text(in_data.ND(node1,2) , in_data.ND(node1,3), in_data.ND(node1,4), num2str(node1));
      set(h,'FontSize',8); set(h,'Color','k');
      h=text(in_data.ND(node2,2) , in_data.ND(node2,3), in_data.ND(node2,4), num2str(node2));
      set(h,'FontSize',8); set(h,'Color','k');
      x1= (in_data.ND(node2,2)-in_data.ND(node1,2))/1.8 + in_data.ND(node1,2);
      y1= (in_data.ND(node2,3)-in_data.ND(node1,3))/1.8 + in_data.ND(node1,3);
      z1= (in_data.ND(node2,4)-in_data.ND(node1,4))/1.8 + in_data.ND(node1,4);
      h=text(x1 , y1, z1, num2str(in_data.EL(i,1))); set(h,'FontSize',6); set(h,'Color','m');
  end;
end;

maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
maxZ = max(in_data.ND(:,4)); minZ = min(in_data.ND(:,4));
dof = size(in_data.ND,1)*6;
labx = (maxX / 9); laby = (maxY / 9); labz = (maxZ / 9);
labx = min([labx laby labz]); laby = labx;  labz=labx;

for i=1:size(in_data.LOAD_)
   node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)+labz],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'r-','LineWidth',3); hold on;
   end;
end;

for i=1:size(in_data.CON)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
   if in_data.CON(i,2)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,3)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0 | in_data.CON(i,5)==0 | in_data.CON(i,6)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'gs','LineWidth',2); hold on;
   end;
end;

rotate3d(gca); set(gcf,'Pointer','arrow');
axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby) (minZ-labz)    (maxZ+labz)]);
hold off;


% ---------------------------------------------------------------------------
function plot_input_brick ( in_data, dof_,PND) 

hold off;

plot3(in_data.ND(:,2),in_data.ND(:,3),in_data.ND(:,4),'y.');
axis equal; axis off; view(3); hold on;
h=title('Input model'); set(h,'FontSize',12);
for i=1:size(in_data.EL)
    node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
    node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
    node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
    node4 = find(in_data.ND(:,1)==in_data.EL(i,6));
    node5 = find(in_data.ND(:,1)==in_data.EL(i,7));
    node6 = find(in_data.ND(:,1)==in_data.EL(i,8));
    node7 = find(in_data.ND(:,1)==in_data.EL(i,9));
    node8 = find(in_data.ND(:,1)==in_data.EL(i,10));

    plot3([in_data.ND(node1,2) in_data.ND(node2,2) in_data.ND(node3,2) in_data.ND(node4,2) in_data.ND(node1,2) ...
          in_data.ND(node5,2) in_data.ND(node6,2) in_data.ND(node7,2) in_data.ND(node8,2) in_data.ND(node5,2)],...
       [in_data.ND(node1,3) in_data.ND(node2,3) in_data.ND(node3,3) in_data.ND(node4,3) in_data.ND(node1,3) ...
          in_data.ND(node5,3) in_data.ND(node6,3) in_data.ND(node7,3) in_data.ND(node8,3) in_data.ND(node5,3)],...
       [in_data.ND(node1,4) in_data.ND(node2,4) in_data.ND(node3,4) in_data.ND(node4,4) in_data.ND(node1,4) ...
          in_data.ND(node5,4) in_data.ND(node6,4) in_data.ND(node7,4) in_data.ND(node8,4) in_data.ND(node5,4)],...
          'Color',[0.4 0.1 0.7],'LineWidth',1);    
    
    plot3([in_data.ND(node2,2) in_data.ND(node6,2) in_data.ND(node7,2) in_data.ND(node3,2) in_data.ND(node2,2) ...
          in_data.ND(node1,2) in_data.ND(node5,2) in_data.ND(node8,2) in_data.ND(node4,2) in_data.ND(node1,2)],...
       [in_data.ND(node2,3) in_data.ND(node6,3) in_data.ND(node7,3) in_data.ND(node3,3) in_data.ND(node2,3) ...
          in_data.ND(node1,3) in_data.ND(node5,3) in_data.ND(node8,3) in_data.ND(node4,3) in_data.ND(node1,3)],...
       [in_data.ND(node2,4) in_data.ND(node6,4) in_data.ND(node7,4) in_data.ND(node3,4) in_data.ND(node2,4) ...
         in_data.ND(node1,4) in_data.ND(node5,4) in_data.ND(node8,4) in_data.ND(node4,4) in_data.ND(node1,4)],...
         'Color',[0.4 0.1 0.7],'LineWidth',1);
     if PND == 1
         h=text(in_data.ND(node1,2) , in_data.ND(node1,3), in_data.ND(node1,4), num2str(node1)); set(h,'FontSize',8); 
         set(h,'Color','k');
         h=text(in_data.ND(node2,2) , in_data.ND(node2,3), in_data.ND(node2,4), num2str(node2)); set(h,'FontSize',8); 
         set(h,'Color','k');
         h=text(in_data.ND(node3,2) , in_data.ND(node3,3), in_data.ND(node3,4), num2str(node3)); set(h,'FontSize',8); 
         set(h,'Color','k');
         h=text(in_data.ND(node4,2) , in_data.ND(node4,3), in_data.ND(node4,4), num2str(node4)); set(h,'FontSize',8); 
         set(h,'Color','k');
         h=text(in_data.ND(node5,2) , in_data.ND(node5,3), in_data.ND(node5,4), num2str(node5)); set(h,'FontSize',8); 
         set(h,'Color','k');
         h=text(in_data.ND(node6,2) , in_data.ND(node6,3), in_data.ND(node6,4), num2str(node6)); set(h,'FontSize',8); 
         set(h,'Color','k');
         h=text(in_data.ND(node7,2) , in_data.ND(node7,3), in_data.ND(node7,4), num2str(node7)); set(h,'FontSize',8); 
         set(h,'Color','k');
         h=text(in_data.ND(node8,2) , in_data.ND(node8,3), in_data.ND(node8,4), num2str(node8)); set(h,'FontSize',8); 
         set(h,'Color','k');
             x1= in_data.ND(node1,2)/8  +  in_data.ND(node2,2)/8 +  in_data.ND(node3,2)/8  + in_data.ND(node4,2)/8 +...
                 in_data.ND(node5,2)/8  +  in_data.ND(node6,2)/8 +  in_data.ND(node7,2)/8  + in_data.ND(node8,2)/8;
             y1= in_data.ND(node1,3)/8  +  in_data.ND(node2,3)/8 +  in_data.ND(node3,3)/8  + in_data.ND(node4,3)/8 +...
                 in_data.ND(node5,3)/8  +  in_data.ND(node6,3)/8 +  in_data.ND(node7,3)/8  + in_data.ND(node8,3)/8;
             z1= in_data.ND(node1,4)/8  +  in_data.ND(node2,4)/8 +  in_data.ND(node3,4)/8  + in_data.ND(node4,4)/8 +...
                 in_data.ND(node5,4)/8  +  in_data.ND(node6,4)/8 +  in_data.ND(node7,4)/8  + in_data.ND(node8,4)/8;
             h=text(x1 , y1, z1, num2str(in_data.EL(i,1))); set(h,'FontSize',6); set(h,'Color','m');
     end;
 end;
 hold on;
 
 maxX = max(in_data.ND(:,2));  minX = min(in_data.ND(:,2));
 maxY = max(in_data.ND(:,3));  minY = min(in_data.ND(:,3));
 maxZ = max(in_data.ND(:,4));  minZ = min(in_data.ND(:,4));
 labx = (maxX / 9); laby = (maxY / 9); labz = (maxZ / 9);
 labx = min([labx laby labz]); laby = labx;  labz=labx;

for i=1:size(in_data.LOAD_)
   node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)+labz],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'r-','LineWidth',3); hold on;
   end;
end;

for i=1:size(in_data.CON)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
   if in_data.CON(i,2)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,3)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0 | in_data.CON(i,5)==0 | in_data.CON(i,6)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'gs','LineWidth',2); hold on;
   end;
end;

rotate3d(gca); set(gcf,'Pointer','arrow');
axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby) (minZ-labz) (maxZ+labz)]);
hold off




function plot_input_tetrah ( in_data, dof_,PND) 

hold off;

axis equal;
if 0
for i=1:size(in_data.EL)
    node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
    node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
    node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
    node4 = find(in_data.ND(:,1)==in_data.EL(i,6));

    plot3([in_data.ND(node1,2) in_data.ND(node2,2) in_data.ND(node3,2) in_data.ND(node1,2)  in_data.ND(node4,2)],...
       [in_data.ND(node1,3) in_data.ND(node2,3) in_data.ND(node3,3)    in_data.ND(node1,3)  in_data.ND(node4,3)],...
       [in_data.ND(node1,4) in_data.ND(node2,4) in_data.ND(node3,4)    in_data.ND(node1,4)  in_data.ND(node4,4)],...
          'Color',[0.4 0.1 0.7],'LineWidth',1);    

    plot3([in_data.ND(node2,2) in_data.ND(node4,2) in_data.ND(node3,2) ],...
       [in_data.ND(node2,3) in_data.ND(node4,3) in_data.ND(node3,3)],...
       [in_data.ND(node2,4) in_data.ND(node4,4) in_data.ND(node3,4)],...
         'Color',[0.4 0.1 0.7],'LineWidth',1);
     if PND == 1
         h=text(in_data.ND(node1,2) , in_data.ND(node1,3), in_data.ND(node1,4), num2str(node1)); set(h,'FontSize',8); 
         set(h,'Color','k');
         h=text(in_data.ND(node2,2) , in_data.ND(node2,3), in_data.ND(node2,4), num2str(node2)); set(h,'FontSize',8); 
         set(h,'Color','k');
         h=text(in_data.ND(node3,2) , in_data.ND(node3,3), in_data.ND(node3,4), num2str(node3)); set(h,'FontSize',8); 
         set(h,'Color','k');
         h=text(in_data.ND(node4,2) , in_data.ND(node4,3), in_data.ND(node4,4), num2str(node4)); set(h,'FontSize',8); 
         set(h,'Color','k');

             x1= in_data.ND(node1,2)/4  +  in_data.ND(node2,2)/4 +  in_data.ND(node3,2)/4  + in_data.ND(node4,2)/4;
             y1= in_data.ND(node1,3)/4  +  in_data.ND(node2,3)/4 +  in_data.ND(node3,3)/4  + in_data.ND(node4,3)/4;
             z1= in_data.ND(node1,4)/4  +  in_data.ND(node2,4)/4 +  in_data.ND(node3,4)/4  + in_data.ND(node4,4)/4;
             h=text(x1 , y1, z1, num2str(in_data.EL(i,1))); set(h,'FontSize',6); set(h,'Color','m');
     end;
 end;
end % ZERO ---
tri2=surftri(in_data.ND(:,2:4),in_data.EL(:,3:6));
trimesh(tri2,in_data.ND(:,2),in_data.ND(:,3),in_data.ND(:,4),'facecolor','none','edgecolor','k'); axis equal
axis off; view(3);
h=title('Input model'); set(h,'FontSize',12);  hold on;

 maxX = max(in_data.ND(:,2));  minX = min(in_data.ND(:,2));
 maxY = max(in_data.ND(:,3));  minY = min(in_data.ND(:,3));
 maxZ = max(in_data.ND(:,4));  minZ = min(in_data.ND(:,4));
 labx = (maxX / 9); laby = (maxY / 9); labz = (maxZ / 9);
 labx = min([labx laby labz]); laby = labx;  labz=labx;

for i=1:size(in_data.LOAD_,1)
   node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)+labz],'r-','LineWidth',3); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'r-','LineWidth',3); hold on;
   end;
end;

for i=1:size(in_data.CON,1)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
   if in_data.CON(i,2)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,3)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0 | in_data.CON(i,5)==0 | in_data.CON(i,6)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'gs','LineWidth',2); hold on;
   end;
end;

axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby) (minZ-labz) (maxZ+labz)]);
rotate3d(gca); set(gcf,'Pointer','arrow');

hold off;




function plot_heat_CST_input ( in_data, dof, NF, PND) 

hold off;
if 1
   maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
   maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
   labx = abs(maxX / 15); laby = abs(maxY / 15);
   labx = max([labx laby]); laby = labx;


   if 0

       % hold on
       for i=1:size(in_data.LOAD_)
           node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
           if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)],'r-','LineWidth',3); hold on;
           end;
           if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)],'r-','LineWidth',3);hold on;
           end;
           if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],'r-','LineWidth',3);hold on;
           end;
           if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],'r-','LineWidth',3);hold on;
           end;
       end;
  

       for i=1:size(in_data.CON)
           node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
           if in_data.CON(i,2)==0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)],'g-','LineWidth',2.5);
           end;
           if in_data.CON(i,3)==0
               plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
                   [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],'g-','LineWidth',2.5);
           end;
       end;
   end; % % -- end if NF > 100
   
   
   plot(in_data.ND(:,2),in_data.ND(:,3),'y.','MarkerSize',2);
   axis equal; axis off; view(2); hold on;
   for i=1:size(in_data.EL)
      yy = 0.9; % color scale: white to black 
      if in_data.EL(i,2)==44   
         node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
         node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
         node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
         plot([in_data.ND(node1,2) in_data.ND(node2,2) in_data.ND(node3,2) in_data.ND(node1,2)], ...
            [in_data.ND(node1,3) in_data.ND(node2,3) in_data.ND(node3,3) in_data.ND(node1,3)],...
            'Color',[0.4 0.1 0.7],'LineWidth',.1);
        if PND == 1
            h=text(in_data.ND(node1,2) , in_data.ND(node1,3), 0, num2str(node1)); set(h,'FontSize',8); 
            set(h,'Color','k');
            h=text(in_data.ND(node2,2) , in_data.ND(node2,3), 0, num2str(node2)); set(h,'FontSize',8); 
            set(h,'Color','k');
            h=text(in_data.ND(node3,2) , in_data.ND(node3,3), 0, num2str(node3)); set(h,'FontSize',8); 
            set(h,'Color','k');
            x1= in_data.ND(node1,2)/3  +  in_data.ND(node2,2)/3 +  in_data.ND(node3,2)/3;
            y1= in_data.ND(node1,3)/3  +  in_data.ND(node2,3)/3 +  in_data.ND(node3,3)/3;
            h=text(x1 , y1, num2str(in_data.EL(i,1))); set(h,'FontSize',6); set(h,'Color','m');
        end;
      end;
 end;

 h=title('Input model'); set(h,'FontSize',12);
 axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby)]); drawnow
 rotate3d(gca); set(gcf,'Pointer','arrow');
 hold off;
 
 % =======END
end
