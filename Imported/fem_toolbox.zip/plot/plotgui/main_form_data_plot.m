function main_form_data_plot (handles,in_data,pax,plot_dyn)

% plot location of DOF for output from dynamic analysis on the main form

axes(pax);

dofN = handles.in_data.dofN;
if isfield(handles.in_data.dynam,'TIMEHPL')
    if length(in_data.dynam.TIMEHPL)~=0
        if handles.in_data.type == '2dbeam'
            vr = ceil(in_data.dynam.TIMEHPL(1)/dofN);
            node = find(in_data.ND(:,1)==vr); hold on;
            if  plot_dyn
                plot(in_data.ND(node,2),in_data.ND(node,3),'b.','MarkerSize',14);
                plot(in_data.ND(node,2),in_data.ND(node,3),'bo','MarkerSize',18);
            end
            labx = (max(in_data.ND(:,2)) / 13); laby = (max(in_data.ND(:,3)) / 13);
            labx = min([labx laby]); laby = labx;
            if in_data.dynam.TIMEHPL(1)-dofN*vr==0
                if  plot_dyn
                    plot(in_data.ND(node,2),in_data.ND(node,3),'bs','MarkerSize',15);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-1
                if  plot_dyn
                    plot([in_data.ND(node,2) in_data.ND(node,2)], ...
                        [in_data.ND(node,3)-laby*2  in_data.ND(node,3)+laby*2],'b-','LineWidth',2);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-2
                if  plot_dyn
                    plot([in_data.ND(node,2)-labx*2 in_data.ND(node,2)+labx*2], ...
                        [in_data.ND(node,3)  in_data.ND(node,3)],'b-','LineWidth',2);
                end
            end
            rotate3d(gca); set(gcf,'Pointer','arrow');
            pause(0.001); hold off;
        end;
        if handles.in_data.type == '3dbeam'
            vr = ceil(in_data.dynam.TIMEHPL(1)/dofN);
            node = find(in_data.ND(:,1)==vr); hold on;
            if  plot_dyn
                plot3(in_data.ND(node,2),in_data.ND(node,3),in_data.ND(node,4),'b.','MarkerSize',14);
                plot3(in_data.ND(node,2),in_data.ND(node,3),in_data.ND(node,4),'bo','MarkerSize',18);
            end
            labx = (max(in_data.ND(:,2))/9); laby=(max(in_data.ND(:,3))/9); labz=(max(in_data.ND(:,4))/9);
            labx = min([labx laby labz]); laby = labx;  labz=labx;
            if in_data.dynam.TIMEHPL(1)-dofN*vr==0 | ...
                    in_data.dynam.TIMEHPL(1)-dofN*vr==-1 | in_data.dynam.TIMEHPL(1)-dofN*vr==-2
                if  plot_dyn
                    plot3(in_data.ND(node,2),in_data.ND(node,3),in_data.ND(node,4),'bs','MarkerSize',15);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-3
                if  plot_dyn
                    plot3([in_data.ND(node,2) in_data.ND(node,2)], ...
                        [in_data.ND(node,3)  in_data.ND(node,3)],...
                        [in_data.ND(node,4)-labz in_data.ND(node,4)+labz],'b-','LineWidth',2);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-4
                if  plot_dyn
                    plot3([in_data.ND(node,2) in_data.ND(node,2)], ...
                        [in_data.ND(node,3)-laby  in_data.ND(node,3)+laby],...
                        [in_data.ND(node,4) in_data.ND(node,4)],'b-','LineWidth',2);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-5
                if  plot_dyn
                    plot3([in_data.ND(node,2)-labx in_data.ND(node,2)+labx], ...
                        [in_data.ND(node,3) in_data.ND(node,3)],...
                        [in_data.ND(node,4) in_data.ND(node,4)],'b-','LineWidth',2);
                end
            end
            rotate3d(gca); set(gcf,'Pointer','arrow');
            pause(0.01); hold off;
        end;
        if handles.in_data.type == 'cstcsq'
            vr = ceil(in_data.dynam.TIMEHPL(1)/dofN);
            node = find(in_data.ND(:,1)==vr); hold on;
            if  plot_dyn
                plot(in_data.ND(node,2),in_data.ND(node,3),'bo','MarkerSize',14);
                plot(in_data.ND(node,2),in_data.ND(node,3),'b.','MarkerSize',18);
            end
            labx = (max(in_data.ND(:,2)) / 22); laby = (max(in_data.ND(:,3)) / 22);
            labx = min([labx laby]); laby = labx;
            if in_data.dynam.TIMEHPL(1)-dofN*vr==0
                if  plot_dyn
                    plot([in_data.ND(node,2) in_data.ND(node,2)], ...
                        [in_data.ND(node,3)-laby  in_data.ND(node,3)+laby],'b-','LineWidth',2);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-1
                if  plot_dyn
                    plot([in_data.ND(node,2)-labx in_data.ND(node,2)+labx], ...
                        [in_data.ND(node,3)  in_data.ND(node,3)],'b-','LineWidth',2);
                end
            end
            rotate3d(gca); set(gcf,'Pointer','arrow');
            pause(0.01); hold off;
        end;
        if handles.in_data.type == '3dbrik'
            vr = ceil(in_data.dynam.TIMEHPL(1)/dofN);
            node = find(in_data.ND(:,1)==vr); hold on;
            if  plot_dyn
                plot3(in_data.ND(node,2),in_data.ND(node,3),in_data.ND(node,4),'b.','MarkerSize',14);
                plot3(in_data.ND(node,2),in_data.ND(node,3),in_data.ND(node,4),'bo','MarkerSize',18);
            end
            labx = (max(in_data.ND(:,2))/9); laby=(max(in_data.ND(:,3))/9); labz=(max(in_data.ND(:,4))/9);
            labx = min([labx laby labz]); laby = labx;  labz=labx;
            if in_data.dynam.TIMEHPL(1)-dofN*vr==0
                if  plot_dyn
                    plot3([in_data.ND(node,2) in_data.ND(node,2)], ...
                        [in_data.ND(node,3)  in_data.ND(node,3)],...
                        [in_data.ND(node,4)-labz in_data.ND(node,4)+labz],'b-','LineWidth',2);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-1
                if  plot_dyn
                    plot3([in_data.ND(node,2) in_data.ND(node,2)], ...
                        [in_data.ND(node,3)-laby  in_data.ND(node,3)+laby],...
                        [in_data.ND(node,4) in_data.ND(node,4)],'b-','LineWidth',2);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-2
                if  plot_dyn
                    plot3([in_data.ND(node,2)-labx in_data.ND(node,2)+labx], ...
                        [in_data.ND(node,3) in_data.ND(node,3)],...
                        [in_data.ND(node,4) in_data.ND(node,4)],'b-','LineWidth',2);
                end
            end
            rotate3d(gca); set(gcf,'Pointer','arrow');
            pause(0.01); hold off;
        end;
        if handles.in_data.type == 'bciz  '
            vr = ceil(in_data.dynam.TIMEHPL(1)/dofN);
            node = find(in_data.ND(:,1)==vr); hold on;
            if  plot_dyn
                plot(in_data.ND(node,2),in_data.ND(node,3),'b.','MarkerSize',14);
                plot(in_data.ND(node,2),in_data.ND(node,3),'bo','MarkerSize',18);
            end
            labx = (max(in_data.ND(:,2)) / 9); laby = (max(in_data.ND(:,3)) / 9);
            labx = min([labx laby]); laby = labx; SCz = .5; labz = SCz/2;
            if in_data.dynam.TIMEHPL(1)-dofN*vr==0
                if  plot_dyn
                    plot3([in_data.ND(node,2) in_data.ND(node,2)], ...
                        [in_data.ND(node,3)-laby  in_data.ND(node,3)+laby],...
                        [0 0],'b-','LineWidth',2);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-1
                if  plot_dyn
                    plot3([in_data.ND(node,2)-labx in_data.ND(node,2)+labx], ...
                        [in_data.ND(node,3) in_data.ND(node,3)],...
                        [0 0],'b-','LineWidth',2);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-2
                if  plot_dyn
                    plot3([in_data.ND(node,2) in_data.ND(node,2)], ...
                        [in_data.ND(node,3)  in_data.ND(node,3)],...
                        [0-labz 0+labz],'b-','LineWidth',2);
                end
            end
            rotate3d(gca); set(gcf,'Pointer','arrow');
            pause(0.01); hold off;
        end;
        %----
        
        
        if handles.in_data.type == '3dtrus'
            vr = ceil(in_data.dynam.TIMEHPL(1)/dofN);
            node = find(in_data.ND(:,1)==vr); hold on;
            if  plot_dyn
                plot3(in_data.ND(node,2),in_data.ND(node,3),in_data.ND(node,4),'b.','MarkerSize',14);
                plot3(in_data.ND(node,2),in_data.ND(node,3),in_data.ND(node,4),'bo','MarkerSize',18);
            end
            labx = (max(in_data.ND(:,2))/3); laby=(max(in_data.ND(:,3))/3); labz=(max(in_data.ND(:,4))/3);
            labx = min([labx laby labz]); laby = labx;  labz=labx;
            if in_data.dynam.TIMEHPL(1)-dofN*vr==0
                if  plot_dyn
                    plot3([in_data.ND(node,2) in_data.ND(node,2)], ...
                        [in_data.ND(node,3)  in_data.ND(node,3)],...
                        [in_data.ND(node,4)-labz in_data.ND(node,4)+labz],'b-','LineWidth',2);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-1
                if  plot_dyn
                    plot3([in_data.ND(node,2) in_data.ND(node,2)], ...
                        [in_data.ND(node,3)-laby  in_data.ND(node,3)+laby],...
                        [in_data.ND(node,4) in_data.ND(node,4)],'b-','LineWidth',2);
                end
            end
            if in_data.dynam.TIMEHPL(1)-dofN*vr==-2
                if  plot_dyn
                    plot3([in_data.ND(node,2)-labx in_data.ND(node,2)+labx], ...
                        [in_data.ND(node,3) in_data.ND(node,3)],...
                        [in_data.ND(node,4) in_data.ND(node,4)],'b-','LineWidth',2);
                end
            end
            rotate3d(gca); set(gcf,'Pointer','arrow');
            pause(0.01); hold off;
        end;
            
        %----

        end;
end;
