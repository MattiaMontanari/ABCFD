function plot_2dbeam_static (in_data,resp)

% PLOT STATIC DISPLACEMENTS OF 2D BEAMS

warning off
NF=2;
figure(NF);
hold off;
dof = size(in_data.ND,1)*3; % total dof

plot(in_data.ND(:,2),in_data.ND(:,3),'y.');
title('Displacements from static loads');
axis equal; axis off; hold on; 
for i=1:size(in_data.EL)
   node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
   node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
   plot([in_data.ND(node1,2) in_data.ND(node2,2)], ...
       [in_data.ND(node1,3) in_data.ND(node2,3)],'y-','LineWidth',1);
end;

maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
labx = (maxX / 6); laby = (maxY / 6);
labx = min([labx laby]); laby = labx;

deN = max([max(abs(resp.static.D(1:3:end)))  max(abs(resp.static.D(2:3:end)))]);
dx = labx *resp.static.D(1:3:dof(1)) /deN;
dy = laby *resp.static.D(2:3:dof(1)) /deN;

plot(in_data.ND(:,2)+dx',in_data.ND(:,3)+dy','m.'); hold on;
set(NF,'name',['  Deformed shape:  max(x) = '  num2str(max(abs(resp.static.D(1:3:end)))) ...
        '.  max(y) = '  num2str(max(abs(resp.static.D(2:3:end))))],'NumberTitle','off');
ND_d = in_data.ND;
ND_d(:,2) = in_data.ND(:,2)+dx';
ND_d(:,3) = in_data.ND(:,3)+dy';
for i=1:size(in_data.EL)
   node1 = find(ND_d(:,1)==in_data.EL(i,3));
   node2 = find(ND_d(:,1)==in_data.EL(i,4));
   plot([ND_d(node1,2) ND_d(node2,2)], [ND_d(node1,3) ND_d(node2,3)],'m-');
end;


for i=1:size(in_data.LOAD_)
   node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],...
          [in_data.ND(node_i,3) in_data.ND(node_i,3)],'r-','LineWidth',2); hold on;
   end;
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
          [in_data.ND(node_i,3) in_data.ND(node_i,3)],'r-','LineWidth',2); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
          [in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],'r-','LineWidth',2); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],...
          [in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],'r-','LineWidth',2); hold on;
   end;
end;

for i=1:size(in_data.CON)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
   if in_data.CON(i,2)==0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],...
          [in_data.ND(node_i,3) in_data.ND(node_i,3)],'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,3)==0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) ...
              in_data.ND(node_i,3)-laby],'g-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0
      plot([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) ...
              in_data.ND(node_i,3)],'gs','LineWidth',2); hold on;
   end;
end;

axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby)]);

