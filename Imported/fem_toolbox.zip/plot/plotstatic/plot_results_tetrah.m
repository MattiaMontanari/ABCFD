function plot_results_tetrah ( in_data, resp, dof_) 


NF =2;
figure(NF);
axis equal; axis off; hold on; view(3);
title('Displacements from static loads');
warning off
 
% -----------------------------------------------------------------
maxX = max(in_data.ND(:,2));   minX = min(in_data.ND(:,2));
maxY = max(in_data.ND(:,3));   minY = min(in_data.ND(:,3));
maxZ = max(in_data.ND(:,4));   minZ = min(in_data.ND(:,4));
labx = (maxX / 2); laby = (maxY / 2); labz = (maxZ / 2);
labx = min([labx laby labz]); laby = labx;  labz=labx;

deN = max([max(abs(resp.static.D(1:3:dof_(1)))) max(abs(resp.static.D(2:3:dof_(1)))) ...
        max(abs(resp.static.D(3:3:dof_(1))))]);
dx = labx *resp.static.D(1:3:dof_(1)) /deN;
dy = laby *resp.static.D(2:3:dof_(1)) /deN;
dz = labz *resp.static.D(3:3:dof_(1)) /deN;

ND_d = in_data.ND;
ND_d(:,2) = in_data.ND(:,2)+dx';
ND_d(:,3) = in_data.ND(:,3)+dy';
ND_d(:,4) = in_data.ND(:,4)+dz';

v = [.8 .8 .8];

    tri2 = surftri(in_data.ND(:,2:4),in_data.EL(:,3:6));
    tot_d = sqrt( (resp.static.D(1:3:dof_(1))).^2 + (resp.static.D(2:3:dof_(1))).^2 + (resp.static.D(3:3:dof_(1))).^2 );
    tot_d = tot_d./max(tot_d);
    trimesh(tri2,ND_d(:,2),ND_d(:,3),ND_d(:,4),'CData',[tot_d'],'facecolor','interp','edgecolor','y');
    hold on;
    trimesh(tri2,in_data.ND(:,2),in_data.ND(:,3),in_data.ND(:,4),'facecolor','none','edgecolor','k');
    axis equal;
    axis off;
    hold on;


hold on; view(3); colormap(hsv);
set(NF,'name',['  Deformed shape. MAX(x) = '  num2str(max(ND_d(:,2))) ...
      '   MAX(y) = ' num2str(max(ND_d(:,3))) '   MAX(z) = ' num2str(max(ND_d(:,4)))],'NumberTitle','off');


% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

labx = (maxX / 7); laby = (maxY / 7); labz = (maxZ / 7);
labx = min([labx laby labz]); laby = labx;  labz=labx;

for i=1:size(in_data.CON)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
   if in_data.CON(i,2)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'k-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,3)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'k-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'k-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0 | in_data.CON(i,5)==0 | in_data.CON(i,6)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'ks','LineWidth',2); hold on;
   end;
end;

% -------------------------------------------------------------------------
rotate3d(gca); set(gcf,'Pointer','arrow');
warning on
