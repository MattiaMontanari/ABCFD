function SF_ = plot_fem_static(in_data, obj, resp, type_analysis, varargin)

% plot static deflections

SF_=[];
if in_data.EL(1,2)==0 | in_data.EL(1,2)==1 | in_data.EL(1,2)==2 |...
        in_data.EL(1,2)==31 dofN = 3; end; % 2D-beam, 3D-TRUSS
if in_data.EL(1,2)==3 dofN = 6; end; % 3D-beam  elements
if in_data.EL(1,2)==4 dofN = 2; end; % CST  elements
if in_data.EL(1,2)==5 | in_data.EL(1,2)==51 dofN = 2; end; % CSQ  elements
if in_data.EL(1,2)==6 dofN = 3; end; % "6" - 3D-BRICK element (8-nodes)
if in_data.EL(1,2)==9 dofN = 3; end; % BCIZ elements
if in_data.EL(1,2)==10 dofN = 3; end; % 3D TETRAHEDRON elements
if in_data.EL(1,2)==44 dofN = 1; end; % 2D heat triangle elements


dof_ = size(in_data.ND,1)*dofN; % total dof

%    if plot_bend_tri (..., A )<100 - don't plot loads & constrains
if in_data.EL(1,2)==9 plot_bend_tri ( in_data, resp, dof_, 120); SF_=0; end; % BCIZ

% heat transfer problem:
if in_data.EL(1,2)==44 
    plot_results_heat(  in_data, resp, dof_, 199, varargin{1} );
end

if in_data.EL(1,2)==4  |  in_data.EL(1,2)==5 | in_data.EL(1,2)==51         % 4 : CST, 5 : CSQ
    SIGsys = CST_CSQ_stress (in_data, resp);
    SF_ = zeros(size(in_data.EL,1), 4);
    SF_(1:size(in_data.EL,1),1)=[1:size(in_data.EL,1)]';
    for i=1:size(in_data.EL,1)
        SF_(i,2:end) = [SIGsys(i*3-(3-1):i*3,1)]';
    end;

    if length(type_analysis)>3 if type_analysis(4)==15 end; % see if RSM is running
    else 
        save FEM_STRESS.txt SF_ -ascii; format;
        disp('---  Elements Stresses saved to "FEM_STRESS.txt": [elem#  x  y  angle(deg)]');
        plot_results_tri(  in_data, SIGsys, resp, dof_, 199, varargin{1} );                                  
    end
end;
if in_data.EL(1,2)==3  plot3D_results(in_data,resp);       end; % 3/31 : 3D-beam
if in_data.EL(1,2)==31 plot3D_results_TRUSS(in_data,resp); end; % 3D-TRUSS
if in_data.EL(1,2)==6                                         % 6 : 3D-brick
    [SIGsys] = BRICK_stress (in_data, resp);
    [SIG_main] = BRICK_stress_main (in_data, SIGsys);
    SF_ = zeros(size(in_data.ND,1), 7);
    SF_(1:size(in_data.EL,1),1)=[1:size(in_data.EL,1)]';
    for i=1:size(in_data.ND,1)
        SF_(i,2:end) = [SIGsys(i,:)];
    end;
    if length(type_analysis)>3 if type_analysis(4)==15 end; % see if RSM is running
    else
        save FEM_STRESS.txt SF_ -ascii; format;
        disp('--- "BRICK" Principal Stresses saved to "FEM_STRESS.txt"');
        plot_results_brick (in_data, resp, dof_, SIG_main);
    end;
end;
if in_data.EL(1,2)==0 | in_data.EL(1,2)==1 | in_data.EL(1,2)==2
    SF_=[];
    if length(type_analysis)>3 if type_analysis(4)==15 end; % see if RSM is running
    else
        plot_2dbeam_static (in_data,resp);                    % "0/1/2" : "FF/FP/PF" 2D-beams
        [SF_]=plot_2dbeam_stat_diagram (in_data,obj,resp,'m',3289);
        plot_2dbeam_stat_diagram (in_data,obj,resp,'v',3297);
        plot_2dbeam_stat_diagram (in_data,obj,resp,'n',3299);
        save FEM_2Dbeam_NVM.txt SF_ -ascii; format;
        disp('--- end axial, shear forces, bending moments saved to "FEM_2Dbeam_NVM.txt"');
    end;
end;

if in_data.EL(1,2)==10                                         % 10 : 3D-TETRAH
    if length(type_analysis)>3 if type_analysis(4)==15 end; % see if RSM is running
    else
        plot_results_tetrah (in_data, resp, dof_);
    end;
end;
