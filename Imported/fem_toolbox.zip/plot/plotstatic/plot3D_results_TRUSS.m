function plot3D_results_TRUSS(in_data,resp)


figure(2);
% plot underformed ==============================================================

axis equal; axis off; hold on; view(3);
title('Stress from static loads (red-tension, blue-compression)');
for i=1:size(in_data.EL)
   node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
   node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
end;

maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
maxZ = max(in_data.ND(:,4)); minZ = min(in_data.ND(:,4));
dof = size(in_data.ND,1)*3; % total dof
labx = (maxX / 20); laby = (maxY / 20); labz = (maxZ / 20);

labx = min([labx laby labz]); laby = labx;  labz=labx;

deN = max([max(resp.static.D(1:3:dof(1)))  max(resp.static.D(2:3:dof(1)))  max(resp.static.D(3:3:dof(1))) ]);
dx = labx *resp.static.D(1:3:dof(1)) ;
dy = laby *resp.static.D(2:3:dof(1)) ;
dz = labz *resp.static.D(3:3:dof(1)) ;

ND_d = in_data.ND;
ND_d(:,2) = in_data.ND(:,2)+dx';
ND_d(:,3) = in_data.ND(:,3)+dy';
ND_d(:,4) = in_data.ND(:,4)+dz';
%----for plot---
ND_d_ = in_data.ND;
ND_d_(:,2) = in_data.ND(:,2)+dx'/deN;
ND_d_(:,3) = in_data.ND(:,3)+dy'/deN;
ND_d_(:,4) = in_data.ND(:,4)+dz'/deN;
%----
for i=1:size(in_data.EL)
   node1 = find(ND_d(:,1)==in_data.EL(i,3));
   node2 = find(ND_d(:,1)==in_data.EL(i,4));
   L_0 = sqrt((in_data.ND(node2,2)-in_data.ND(node1,2))^2 + (in_data.ND(node2,3)-in_data.ND(node1,3))^2 + ...
       (in_data.ND(node2,4)-in_data.ND(node1,4))^2);
   L_1 = sqrt((ND_d(node2,2)-ND_d(node1,2))^2 + (ND_d(node2,3)-ND_d(node1,3))^2 + ...
       (ND_d(node2,4)-ND_d(node1,4))^2);
   dL = L_1-L_0;
   E = in_data.EL(i,5);
   stress(i,:) = [ i E*dL/L_0 ]; 
end;
STRmax = max(stress(:,2)); 
STRmin = min(stress(:,2)); 

for i=1:size(in_data.EL)
   node1 = find(ND_d(:,1)==in_data.EL(i,3));
   node2 = find(ND_d(:,1)==in_data.EL(i,4));
   if stress(i,2)>0 % RED for tension
       plot3([ND_d_(node1,2) ND_d_(node2,2)], [ND_d_(node1,3) ND_d_(node2,3)], ... 
           [ND_d_(node1,4) ND_d_(node2,4)],'Color',[abs(stress(i,2)/STRmax) 0.1 0],'LineWidth',1);
   end
   if stress(i,2)<0 % BLUE for compression
       plot3([ND_d_(node1,2) ND_d_(node2,2)], [ND_d_(node1,3) ND_d_(node2,3)], ... 
           [ND_d_(node1,4) ND_d_(node2,4)],'Color',[0 0.1 abs(stress(i,2)/STRmin)],'LineWidth',1);
   end
   if stress(i,2)==0 % GREEN for zero stress
       plot3([ND_d_(node1,2) ND_d_(node2,2)], [ND_d_(node1,3) ND_d_(node2,3)], ... 
           [ND_d_(node1,4) ND_d_(node2,4)],'Color',[0 1 0],'LineWidth',1);
   end
end;

dPath = which ('tmp_dir.txt');     % path to "tmp" directory
cd (dPath(1:end-11));              % path to temp directory: ..\fem\tmp
save FEM_STATIC_TRUSS_stress.txt stress -ascii;
disp(['TRUSS stresses --> "FEM_STATIC_TRUSS_stress.txt']);
clear stress ND_d_
% plot loads --------------------------------------------------------------------
if 0
for i=1:size(in_data.LOAD_)
   node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'g-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)+labz],'g-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'g-','LineWidth',4); hold on;
   end;
end;
end % END IF 0
% plot c --------------------------------------------------------------
for i=1:size(in_data.CON)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
   if in_data.CON(i,2)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'b-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,3)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'b-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'b-','LineWidth',2); hold on;
   end;
   if in_data.CON(i,4)==0 | in_data.CON(i,5)==0 | in_data.CON(i,6)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'bs','LineWidth',2); hold on;
   end;
end;

axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby) (minZ-labz)    (maxZ+labz)]);
rotate3d(gca); set(gcf,'Pointer','arrow');
hold off;
