function plot3D_results(in_data,resp)


figure(2);
% plot underformed ==============================================================
plot3(in_data.ND(:,2),in_data.ND(:,3),in_data.ND(:,4),'k.');
axis equal; axis off; hold on; view(3);
title('Displacements from static loads');
for i=1:size(in_data.EL)
   node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
   node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
   plot3([in_data.ND(node1,2) in_data.ND(node2,2)], ...
      [in_data.ND(node1,3) in_data.ND(node2,3)],[in_data.ND(node1,4) in_data.ND(node2,4)],'k-','LineWidth',1);
end;
% -----------------------------------------------------------------
maxX = max(in_data.ND(:,2)); minX = min(in_data.ND(:,2));
maxY = max(in_data.ND(:,3)); minY = min(in_data.ND(:,3));
maxZ = max(in_data.ND(:,4)); minZ = min(in_data.ND(:,4));
dof = size(in_data.ND,1)*6;
labx = (maxX / 6); laby = (maxY / 6); labz = (maxZ / 6);

labx = min([labx laby labz]); laby = labx;  labz=labx;

deN = max([max(resp.static.D(1:6:dof(1)))  max(resp.static.D(2:6:dof(1)))  max(resp.static.D(3:6:dof(1))) ]);
dx = labx *resp.static.D(1:6:dof(1)) /deN;
dy = laby *resp.static.D(2:6:dof(1)) /deN;
dz = labz *resp.static.D(3:6:dof(1)) /deN;

plot3(in_data.ND(:,2)+dx',in_data.ND(:,3)+dy', in_data.ND(:,4)+dz','r.'); hold on;
ND_d = in_data.ND;
ND_d(:,2) = in_data.ND(:,2)+dx';
ND_d(:,3) = in_data.ND(:,3)+dy';
ND_d(:,4) = in_data.ND(:,4)+dz';
for i=1:size(in_data.EL)
   node1 = find(ND_d(:,1)==in_data.EL(i,3));
   node2 = find(ND_d(:,1)==in_data.EL(i,4));
   plot3([ND_d(node1,2) ND_d(node2,2)], [ND_d(node1,3) ND_d(node2,3)], ... 
      [ND_d(node1,4) ND_d(node2,4)],'r-','LineWidth',2);
end;

for i=1:size(in_data.LOAD_)
   node_i = find(in_data.ND(:,1)==in_data.LOAD_(i,1));
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)+labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,2)~=0 & in_data.LOAD_(i,2)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)+laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,3)~=0 & in_data.LOAD_(i,3)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'r-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)>0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)+labz],'r-','LineWidth',4); hold on;
   end;
   if in_data.LOAD_(i,4)~=0 & in_data.LOAD_(i,4)<0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'r-','LineWidth',4); hold on;
   end;
end;

for i=1:size(in_data.CON)
   node_i = find(in_data.ND(:,1)==in_data.CON(i,1));
   if in_data.CON(i,2)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)-labx],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'b-','LineWidth',3); hold on;
   end;
   if in_data.CON(i,3)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)-laby],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'b-','LineWidth',3); hold on;
   end;
   if in_data.CON(i,4)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)-labz],'b-','LineWidth',3); hold on;
   end;
   if in_data.CON(i,4)==0 | in_data.CON(i,5)==0 | in_data.CON(i,6)==0
      plot3([in_data.ND(node_i,2) in_data.ND(node_i,2)],[in_data.ND(node_i,3) in_data.ND(node_i,3)],...
         [in_data.ND(node_i,4) in_data.ND(node_i,4)],'bs','LineWidth',3); hold on;
   end;
end;

axis([(minX-labx) (maxX+labx) (minY-laby) (maxY+laby) (minZ-labz)    (maxZ+labz)]);
rotate3d(gca); set(gcf,'Pointer','arrow');
hold off;