function [obj,L] = K_CON (dofN, dof_, obj, in_data)

dofs = dof_; 
L0 = [1:dofs];

ind = 1;
for i=1:size(in_data.CON,1)
    for k=1:dofN
        if in_data.CON(i,1+k)==0 
             L(ind) = in_data.CON(i,1)*dofN-(dofN-k);
             ind = ind+1;
         end;
    end;
end;

L=setdiff(L0,L);
disp(['  ...   L vector formed']);


