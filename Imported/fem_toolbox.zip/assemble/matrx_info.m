function matrx_info (A)




[V,D] = eigs(A,length(A));
K = round(condest(V));

sp_=sprintf('\n');
disp([sp_ '     conditioning number (0 (well-conditioned) ... ~ 1e5 (ill-conditioned)):' ]);
disp([ '     K(A) = '  num2str(K)   sp_]);


