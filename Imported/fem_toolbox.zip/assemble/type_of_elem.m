function [dofN,EL_TYPE] = type_of_elem (in_data)


sp_=sprintf('\n');

EL_TYPE = in_data.EL(1,2);

switch EL_TYPE
case {0,1,2,31}
    disp([sp_ '     2D beams']);    dofN=3;   
case {3}
    disp([sp_ '     3D beams']);    dofN = 6;  
case {4}
    disp([sp_ '     CST elem.']);   dofN = 2;  
case {5,51}
    disp([sp_ '     CSQ elem.']);   dofN = 2;  
case {6}
    disp([sp_ '     3D-brick']);    dofN = 3;  
case {9}
    disp([sp_ '     BCIZ plate']);  dofN = 3;
case {10}
    disp([sp_ '     Tetrahedron 3D']);  dofN = 3;
case {44}
    disp([sp_ '     Heat 2D']);    dofN = 1;
otherwise
    disp('     Unknown element'); return;
end