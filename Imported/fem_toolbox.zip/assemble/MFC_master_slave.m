function [u,T,slaves_yes] = MFC_master_slave (K,L,force,slaves,master,do_displ)


dim    = size(K,1);
T      = speye(dim);

not_slaves  = [1:dim]; % vector [1 2 3 ... dof]

for i=1:size(slaves,2)
    T(slaves(i).a,master(i).a)=1;
    not_slaves = setdiff(not_slaves,slaves(i).a);
end
slaves_yes = setdiff([1:dim],not_slaves);

not_slaves=intersect(not_slaves,L);
T=T(:,not_slaves); 
u = 0;         

if do_displ==1
    u = zeros(length(not_slaves),1);
    K=T'*K*T; 
    f1=T'*force';  
    u = (K)\f1;
    u = T*u;         
end

