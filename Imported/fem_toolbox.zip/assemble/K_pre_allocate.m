function [Kgl] = K_pre_allocate (in_data, Nrows, Ncols)


EL_TYPE = in_data.EL(1,2);

switch EL_TYPE
case {0,1,2,31}
    dofN=3; nds = 2;        
    C = sort([in_data.EL(:,3:nds+2).*dofN   in_data.EL(:,3:nds+2).*dofN-1  in_data.EL(:,3:nds+2).*dofN-2],2);
    for i=1:dofN*nds
        W=repmat(C(:,i),1,dofN*nds)'; W1(:,i)=W(:);
    end
    
    DDOF = min(W1([1:dofN*nds:end],:)');
    for i=1:length(DDOF)
        A(:,i)=DDOF(i):1:DDOF(i)+(dofN+nds);
    end
    Q=repmat(A(:),1,nds*dofN)'; Q=Q(:);
    
    W1=W1';
    Kgl=(sparse(Q,W1(:),eps, Nrows, Ncols));
    Kgl = Kgl+Kgl';
case {3}
    dofN = 6; nds = 2;
case {4}
    dofN = 2; nds = 3;      
case {5,51}
    dofN = 2; nds = 4;      
case {6}
    dofN = 3; nds = 8;      
case {9}
    dofN = 3; nds = 3;      
case {10}
    dofN = 3; nds = 4;      
    C = sort([in_data.EL(:,3:nds+2).*dofN   in_data.EL(:,3:nds+2).*dofN-1  in_data.EL(:,3:nds+2).*dofN-2],2);
    for i=1:dofN*nds
        W=repmat(C(:,i),1,dofN*nds)'; W1(:,i)=W(:);
    end
    
    DDOF = min(W1([1:dofN*nds:end],:)'); 
    for i=1:length(DDOF)
        A(:,i)=DDOF(i):1:DDOF(i)+(dofN+nds);
    end
    Q=repmat(A(:),1,nds*dofN)'; Q=Q(:);
    
    W1=W1';
    Kgl=(sparse(Q,W1(:),eps, Nrows, Ncols));
    Kgl = Kgl+Kgl';
    figure(21), spy(Kgl); pause(10);
case {44}
    dofN = 1; nds = 3;
otherwise
    return;
end



