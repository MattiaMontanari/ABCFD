function [M] = M_2D_beam_assembly (in_data)

dof_per_node = 3;
dof = size(in_data.ND)*dof_per_node;
M   = spalloc(dof(1),dof(1),1);


for i=1:size(in_data.MASS,1)
    t4 = in_data.MASS(i,1)*dof_per_node-(dof_per_node-1);
    if in_data.MASS(i,2)>0
        M(t4,t4)  = in_data.MASS(i,2);
    end;
    if in_data.MASS(i,3)>0
        M(t4+1,t4+1) = in_data.MASS(i,3);
    end;
    if in_data.MASS(i,4)>0
        M(t4+2,t4+2) = in_data.MASS(i,4);
    end;
end;
