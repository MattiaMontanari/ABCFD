function KM_info (K, M)

[V,D] = eigs(M\K,length(M));
k = round(condest(V));

sp_=sprintf('\n');
disp([sp_ '     conditioning number (0 (well-conditioned) ... ~ 1e10 (ill-conditioned)):' ]);
disp([ '     K = '  num2str(k)   sp_]);




