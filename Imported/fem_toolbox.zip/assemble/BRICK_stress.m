function [SIGsys] = BRICK_stress (in_data, resp)



fj = size(in_data.EL);
SIGsys = zeros(size(in_data.ND,1),1);

for i=1:fj(1) 
   if in_data.EL(i,2)==6
      node1 = find(in_data.ND(:,1)==in_data.EL(i,3));
      node2 = find(in_data.ND(:,1)==in_data.EL(i,4));
      node3 = find(in_data.ND(:,1)==in_data.EL(i,5));
      node4 = find(in_data.ND(:,1)==in_data.EL(i,6));
      node5 = find(in_data.ND(:,1)==in_data.EL(i,7));
      node6 = find(in_data.ND(:,1)==in_data.EL(i,8));
      node7 = find(in_data.ND(:,1)==in_data.EL(i,9));
      node8 = find(in_data.ND(:,1)==in_data.EL(i,10));
      Em    = in_data.EL(i,11);
      miu_1 = in_data.EL(i,12);
      rho_  = in_data.EL(i,13);
      
      [Klc,B_lc,E_lc,V] = D3_LB (in_data.ND(node1,2),in_data.ND(node1,3),in_data.ND(node1,4),...
         in_data.ND(node2,2),in_data.ND(node2,3),in_data.ND(node2,4),in_data.ND(node3,2),in_data.ND(node3,3),...
         in_data.ND(node3,4),in_data.ND(node4,2),in_data.ND(node4,3),in_data.ND(node4,4),in_data.ND(node5,2),...
         in_data.ND(node5,3),in_data.ND(node5,4),in_data.ND(node6,2),in_data.ND(node6,3),in_data.ND(node6,4),...
         in_data.ND(node7,2),in_data.ND(node7,3),in_data.ND(node7,4),in_data.ND(node8,2),in_data.ND(node8,3),...
         in_data.ND(node8,4), Em, miu_1);
      Dlocal = [resp.static.D(node1*3-2) resp.static.D(node1*3-1) resp.static.D(node1*3) ...
              resp.static.D(node2*3-2) resp.static.D(node2*3-1) resp.static.D(node2*3)  ...
              resp.static.D(node3*3-2) resp.static.D(node3*3-1) resp.static.D(node3*3) ...
              resp.static.D(node4*3-2) resp.static.D(node4*3-1) resp.static.D(node4*3) ...
              resp.static.D(node5*3-2) resp.static.D(node5*3-1) resp.static.D(node5*3) ...
              resp.static.D(node6*3-2) resp.static.D(node6*3-1) resp.static.D(node6*3) ...
              resp.static.D(node7*3-2) resp.static.D(node7*3-1) resp.static.D(node7*3) ...
              resp.static.D(node8*3-2) resp.static.D(node8*3-1) resp.static.D(node8*3)];
      
      SIGlocal_c = E_lc*B_lc(:,:,1)*Dlocal';
      SIGlocal_1 = E_lc*B_lc(:,:,2)*Dlocal';
      SIGlocal_2 = E_lc*B_lc(:,:,3)*Dlocal';
      SIGlocal_3 = E_lc*B_lc(:,:,4)*Dlocal';
      SIGlocal_4 = E_lc*B_lc(:,:,5)*Dlocal';
      SIGlocal_5 = E_lc*B_lc(:,:,6)*Dlocal';
      SIGlocal_6 = E_lc*B_lc(:,:,7)*Dlocal';
      SIGlocal_7 = E_lc*B_lc(:,:,8)*Dlocal';
      SIGlocal_8 = E_lc*B_lc(:,:,9)*Dlocal';
      
      SIGsys(node1,1:6) = SIGlocal_1';
      SIGsys(node2,1:6) = SIGlocal_2';
      SIGsys(node3,1:6) = SIGlocal_3';
      SIGsys(node4,1:6) = SIGlocal_4';
      SIGsys(node5,1:6) = SIGlocal_5';
      SIGsys(node6,1:6) = SIGlocal_6';
      SIGsys(node7,1:6) = SIGlocal_7';
      SIGsys(node8,1:6) = SIGlocal_8';
  end;   
end;

