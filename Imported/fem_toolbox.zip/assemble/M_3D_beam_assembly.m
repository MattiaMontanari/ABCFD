function [M] = M_3D_beam_assembly (in_data)


    dof_per_node = 6;
    dof = size(in_data.ND)*dof_per_node;
    M   = spalloc(dof(1),dof(1),1);


for i=1:size(in_data.MASS)
    t4 = in_data.MASS(i,1)*6-5;
    if in_data.MASS(i,2)>0
        M(t4,t4)  = in_data.MASS(i,2);
    end;
    if in_data.MASS(i,3)>0
        M(t4+1,t4+1) = in_data.MASS(i,3);
    end;
    if in_data.MASS(i,4)>0
        M(t4+2,t4+2) = in_data.MASS(i,4);
    end;
    if in_data.MASS(i,5)>0
        M(t4+3,t4+3) = in_data.MASS(i,5);
    end;
    if in_data.MASS(i,6)>0
        M(t4+4,t4+4) = in_data.MASS(i,6);
    end;
    if in_data.MASS(i,7)>0
        M(t4+5,t4+5) = in_data.MASS(i,7);
    end;
end;
