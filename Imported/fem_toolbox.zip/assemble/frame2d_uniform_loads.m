function [LV] = frame2d_uniform_loads (in_data,L_,LVEC)


dof_   = size(in_data.ND,1)*3;
Nbeams = size(in_data.EL,1);
LV     = sparse(dof_,1,1);

for b=1:Nbeams

    node1 = find(in_data.ND(:,1)==in_data.EL(b,3));
    node2 = find(in_data.ND(:,1)==in_data.EL(b,4));

    x1 = in_data.ND(node1,2); y1 = in_data.ND(node1,3);
    x2 = in_data.ND(node2,2); y2 = in_data.ND(node2,3);
    L =  sqrt((x2-x1)^2+(y2-y1)^2);

    g = [ 3*node1-2 ; 3*node1-1 ; 3*node1 ; 3*node2-2 ; 3*node2-1 ; 3*node2 ];

    P_local = [ 0 ; in_data.q(b)*L/2 ; in_data.q(b)*L^2/12 ; 0 ; ...
              in_data.q(b)*L/2 ; -in_data.q(b)*L^2/12 ];
    c = (x2-x1) / L;
    s = (y2-y1) / L;

    T = [ c s 0   0 0 0 ;
         -s c 0   0 0 0 ;
          0 0 1   0 0 0 ;
          0 0 0   c s 0 ;
          0 0 0  -s c 0 ;
          0 0 0   0 0 1 ];

    LV(g) = LV(g) + T' * P_local;
end
LV = LV';

