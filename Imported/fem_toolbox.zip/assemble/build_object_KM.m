function [obj,L,break_K] = build_object_KM (in_data,type_analysis)

[dofN] = type_of_elem (in_data);
dof_   = size(in_data.ND,1)*dofN;

in_data.SUB = 1;

if  isfield(in_data,'SUB')
    switch in_data.SUB
        case 2
            disp([' static condensation:  2']);
            HF = floor((dof_/2)/dofN)*dofN;
            break_K = [ 1 HF HF+1  dof_ ];
            [obj.Ksys.Kgl_11, obj.M_11] = K_assembly (in_data,type_analysis,break_K(1:2),break_K(1:2));
            [obj.Ksys.Kgl_12, obj.M_12] = K_assembly (in_data,type_analysis,break_K(1:2),break_K(3:4));
            obj.Ksys.Kgl_21 = obj.Ksys.Kgl_12';
            obj.M_21 = obj.M_12';
            [obj.Ksys.Kgl_22, obj.M_22] = K_assembly (in_data,type_analysis,break_K(3:4),break_K(3:4));
        case 1
            break_K = [1 dof_];
            disp(' static condensation: NONE');
            [obj.Ksys.Kgl, obj.M] = K_assembly (in_data,type_analysis,[1 dof_],[1 dof_]);
        otherwise
            disp(' !!! Check static condensation parameter');
            return;
    end
else
    break_K = [1 dof_];
    disp(' static condensation: NONE');
    [obj.Ksys.Kgl, obj.M] = K_assembly (in_data,type_analysis,break_K,break_K);
end

sp_=sprintf('\n');
disp([sp_  '  ...   K, M - completed.']);

if  isfield(in_data,'T')
    L=0;
else
    [obj,L] = K_CON (dofN, dof_, obj, in_data); % add constraints
end

disp([sp_  '  ...   Vector of constraints -- OK.']); % Time (sec): ' num2str(toc)]);


