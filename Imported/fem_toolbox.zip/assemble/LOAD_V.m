function [LV] = LOAD_V (dofN, dof_, in_data, L)

LV = spalloc(1,dof_,1);

for i=1:size(in_data.LOAD_,1)
   t4 = in_data.LOAD_(i,1)*dofN-(dofN-1);
   for k=1:size(in_data.LOAD_,2)-1
       LV(t4+k-1)     = in_data.LOAD_(i,k+1);
   end;
end;

%LV = LV_(L);
