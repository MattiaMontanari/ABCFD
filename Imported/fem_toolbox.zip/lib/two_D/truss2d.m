function [K,M] = truss2d (x1, y1, x2, y2, E, A)

% 2D truss element stiffness and mass matrix in global coordinates


L = sqrt((x2-x1)^2 + (y2-y1)^2 ); 
c = (x2-x1) / L;
s = (y2-y1) / L;

K = [c^2  c*s -c^2 -c*s ;
     c*s  s^2 -c*s -s^2 ;
    -c^2 -c*s  c^2  c*s ;
    -c*s -s^2  c*s  s^2 ];
 
K = K*E*A/L;

M = (rho*A*L/6)*[2 0 1 0; 0 2 0 1; 1 0 2 0; 0 1 0 2];

