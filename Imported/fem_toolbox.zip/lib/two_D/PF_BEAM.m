function [M,K] = PF_BEAM (x1, y1, x2, y2, E, A, I, rho)

% returns a 2D pinned-fixed beam element stiffness & mass matrix in global coordinates


L = sqrt((x2-x1)^2 + (y2-y1)^2 );
c = (x2-x1) / L; 
s = (y2-y1) / L;
Y = E*A;
Z = E*I;

Ke = [Y/L    0      0      -Y/L       0       0;
     0   3*Z/L^3    0       0   -3*Z/L^3    3*Z/L^2;
     0      0       0       0         0       0;
     -Y/L   0       0       Y/L       0       0;
     0  -3*Z/L^3    0       0    3*Z/L^3  -3*Z/L^2;
     0   3*Z/L^2    0       0   -3*Z/L^2   3*Z/L];
 
Me = (rho*A*L/420)*[140      0      0   70      0        0;
                      0    156      0    0     54    -13*L;
                      0      0      0    0      0        0;
                     70      0      0  140      0        0;
                      0     54      0    0    156    -22*L;
                      0  -13*L      0    0  -22*L    4*L^2];

T =  [ c s 0   0 0 0 ;
      -s c 0   0 0 0 ;
       0 0 1   0 0 0 ;
       0 0 0   c s 0 ;
       0 0 0  -s c 0 ;
       0 0 0   0 0 1 ];

K = T'*Ke*T;		
M = T'*Me*T;

