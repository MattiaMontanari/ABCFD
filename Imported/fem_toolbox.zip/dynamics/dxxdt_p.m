function xd = dxxdt_p(t,x)


global dof h CH CH2 C K zdd delta_t % CH_1 CH_2

ku = max(1,floor(t/delta_t));                    
zddnow = zdd(ku) + (zdd(ku+1)-zdd(ku))*(t/delta_t - ku);

displ = x(1:dof);                                
veloc = x(dof+1:2*dof);                          
 accel = -CH\(CH2\(C*veloc + K*displ)) - h*zddnow;
xd = [ veloc; accel ];


