function [E_Vec_ok, wn] = modal_analysis ( obj , L, in_data)


   dofs =  size(obj.M(L,L),1);
   
   [G_fact, E_Vec, eig_Values] = ...
      eigFEM (obj.Ksys.Kgl(L,L), obj.M(L,L), (ones(dofs,1).*in_data.dynam.DAMP_C(1))');  
   N=2; 
   bet = (2*in_data.dynam.DAMP_C(1)*eig_Values(dofs -(N-1))-2*in_data.dynam.DAMP_C(1)*eig_Values(dofs))/...
      (eig_Values(dofs-(N-1))^2-eig_Values(dofs)^2);
   alp = 2*in_data.dynam.DAMP_C(1)*eig_Values(dofs-(N-1)) - ...
      bet*eig_Values(dofs -(N-1))^2;

   [wn,damp] = freq_damp_FEM(obj.Ksys.Kgl(L,L),obj.M(L,L),alp,bet); 

   k=1;
   sd = size(E_Vec);
   E_Vec_ok = zeros(length(obj.M),sd(1));
   E_Vec_ok(L,:) = E_Vec;
