function xd = dxdtU(t,x,u,params)


global dof h CH CH2 C K delta_t % CH_1 CH_2 % Mi 

zddnow = u;

displ = x(1:dof);                                
veloc = x(dof+1:2*dof);                          
accel = -CH\(CH2\(C*veloc + K*displ)) - h*zddnow;
xd = [ veloc; accel ];                      

