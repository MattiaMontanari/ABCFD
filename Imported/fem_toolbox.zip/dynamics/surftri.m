function RT = surftri(p,t)

UT  = [t(:,[1,2,3]);
       t(:,[1,2,4]);
       t(:,[1,3,4]);
       t(:,[2,3,4])];
mqr = [t(:,4);t(:,3);t(:,2);t(:,1)];
UT  =sort(UT,2);

[foo,ix,jx] = unique(UT, 'rows');
vec = histc(jx,1:max(jx));

qx = find(vec==1);
RT = UT(ix(qx),:);
mqr= mqr(ix(qx));

v1 = p(RT(:,2),:)-p(RT(:,1),:);
v2 = p(RT(:,3),:)-p(RT(:,1),:);
v3 = p(mqr,:)-p(RT(:,1),:);

ix = find(dot(cross(v1,v2,2),v3,2)>0);

RT(ix,[2,3]) = RT(ix,[3,2]);

