function [ E_Vec, eig_Values] = eigFEM_s (K, M, N)

% ---------------------------------------------------------------------
NEG = N;
opts.maxit = 270;
opts.tol   = 5;
[eig_vect, eig_val]=eigs(K,M,NEG,'SM',opts);
eig_val    = sqrt(real(eig_val));
eig_V      = diag(eig_val);
eig_vect   = real(eig_vect);
D          = size(eig_vect,1);

NOM=0;
DIN=realmax;
S=0;

for i=1:NEG
   for k=1:NEG
      if abs(eig_V(k))>=abs(NOM)
         if abs(eig_V(k))<abs(DIN)
             NOM=eig_V(k); S=k;
         end;
      end;
   end;
   eig_Values(i)=NOM; DIN=NOM;
   for p=1:D
       E_Vec(p,i)=eig_vect(p,S);
   end;
   NOM=0;
end;

idx = 1;
fprintf('-------------- First eigen-values -------------- \n');
fprintf('------------------------------------------------ \n');
for i=length(eig_Values):-1:1
    fprintf('# %d: %5.6f [sec] : %5.6f [Hz] \n', idx, ...
        2*pi/eig_Values(i), eig_Values(i)/(2*pi));
    idx = idx + 1;
end
fprintf('------------------------------------------------ \n');

