function [G, eig_vect, eig_V] = eigFEM (K, M, damp)

warning off
[eig_vect, eig_val]=eig(full(K),full(M));
warning on
eig_val=sqrt(real(eig_val));    

eig_V=diag(eig_val);
eig_vect=real(eig_vect);

D = length(damp);                


NOM=0; DIN=0;
for k=1:D
   for i=1:D
      NOM=M(i,i)*eig_vect(i,k)+NOM;
      DIN=M(i,i)*eig_vect(i,k)*eig_vect(i,k)+DIN;
   end;
   G(k)=-NOM/DIN;              
   NOM=0; DIN=0;
end;

[eig_V,indx ] = sort(eig_V,'descend');
eig_vect = (eig_vect(:,indx));        
G = G(indx);                          

disp(['  egenvalues -- done'])

