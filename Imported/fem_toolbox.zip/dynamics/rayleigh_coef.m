function [alph, bet] = rayleigh_coef (K,M,damp,N)

[ E_Vec, eig_Val] = eigFEM_s (K, M, N);

bet  = (2*damp(2)*eig_Val(1)-2*damp(1)*eig_Val(N))/(eig_Val(1)^2-eig_Val(N)^2);
alph = 2*damp(2)*eig_Val(1) - bet*eig_Val(1)^2;

