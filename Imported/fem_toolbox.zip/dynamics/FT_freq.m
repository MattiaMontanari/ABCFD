function [FT_T,omega] = FT_freq (T,dt)


if nargin==0 T=rand(2000,1); dt=0.005; end;

T = [T ; zeros(1500,1)];

z = length(T);
omega = [1:z].*(2*pi)./(z*dt); mF=floor(z/7); 

FT_T = fft(T);
fm=(2*pi)./omega(  find(FT_T(:)==max(FT_T)));

omega = omega(1:mF)./(2*pi); % Hz

FT_T = abs(FT_T(1:mF));
