function [wn,E_Vec_ok] = modal_analysis_large ( obj , L, in_data)

% --------------------------------------------------------------------

[E_Vec, wn]   = eigFEM_s (obj.Ksys.Kgl(L,L), obj.M(L,L), in_data.dynam.MODA);
sd            = in_data.dynam.MODA;
E_Vec_ok      = zeros(length(obj.M),1);
E_Vec_ok(L,:) = E_Vec(:, size(E_Vec,2)-sd+1);
