function  fea_modal_analysis (obj,in_data,L,dof_)


if      in_data.EL(1,2)==4  | in_data.EL(1,2)==5  | in_data.EL(1,2)==3  | ...
        in_data.EL(1,2)==6  | in_data.EL(1,2)==0  | in_data.EL(1,2)==1  | ...
        in_data.EL(1,2)==2  | in_data.EL(1,2)==9  | in_data.EL(1,2)==51 | ...
        in_data.EL(1,2)==31 | in_data.EL(1,2)==10
    if size(obj.Ksys.Kgl(L,L),1)<200
        [E_Vec_ok, wn] = modal_analysis ( obj , L, in_data);
        resp.modal.wn = 2*pi./wn;
        i = size(E_Vec_ok);
        plot_modal_shape(in_data,E_Vec_ok,dof_,3413);
        mode_T_sec = 2*pi/wn(in_data.dynam.MODA);
        sp_=sprintf('\n');
        title([sp_ 'Mode shape:  '  num2str(in_data.dynam.MODA) '.  T =  ' num2str(mode_T_sec) '  s']);
        disp([sp_ '--------- MODAL ANALYSIS DONE ---------']);
    else
        [wn,E_Vec_ok] = modal_analysis_large ( obj , L, in_data);
        plot_modal_shape(in_data,E_Vec_ok',dof_,3413);
        title(['Mode: ' num2str(length(wn)) '. Frequency: ' num2str(wn(1+length(wn)-in_data.dynam.MODA(1))/(2*pi)) ' [Hz]'])
    end

end;
