function  [resp,t] = fea_dynamic_analysis (obj,in_data,L,LK)

% =========================================================================
% FEM analysis toolbox for solid mechanics. Project started: Aug 2004
% Anton Zaicenco <a.zaicenco@codedevelopment.net>
% =========================================================================


if in_data.EL(1,2)==9 | in_data.EL(1,2)==4 | in_data.EL(1,2)==5 | ...
        in_data.EL(1,2)==3 | in_data.EL(1,2)==6 | in_data.EL(1,2)==0 ...
        | in_data.EL(1,2)==1 | in_data.EL(1,2)==2 | in_data.EL(1,2)==51 ...
        | in_data.EL(1,2)==10 | in_data.EL(1,2)==31
    [resp.dynamic.dva, t] = dyn_FEM ( in_data, obj, L,LK);
end; 
        zdd    = load(in_data.dynam.TIMEH);

A = which ('tmp_dir.txt'); cd (A(1:end-12));    % path to temp dir: ..\fem\tmp
sp_=sprintf('\n');
disp([sp_ '--- Dynamic response --> "FEM_DYN_RESP.txt"']);

