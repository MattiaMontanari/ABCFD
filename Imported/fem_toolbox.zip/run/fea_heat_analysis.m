function [resp] = fea_heat_analysis (obj,in_data,dofN,dof_,type_analysis,varargin)

% =========================================================================
% FEM analysis toolbox for solid mechanics. Project started: Aug 2004
% Anton Zaicenco <a.zaicenco@codedevelopment.net>
% =========================================================================


dPath = which ('tmp_dir.txt'); % path to "tmp" directory - like: ..\fem\tmp
cd (dPath(1:end-11));

sp_=sprintf('\n');
disp([sp_  '  ...   Load vector - completed.     Time (sec): ' num2str(toc)]);


            if  isfield(in_data,'DBC')
                L = setdiff([1:size(obj.Ksys.Kgl,1)],in_data.DBC.dofs);  
                [displacements] = DBC_solve (obj.Ksys.Kgl,L,obj.M',in_data);
                resp.static.temperature = displacements' ;
            else
                CHL = chol(obj.Ksys.Kgl);
                resp.static.temperature = CHL\(CHL'\obj.M); clear CHL;
            end

disp([sp_  '  ...   temperatures - solved.      Time (sec): ' num2str(toc)]);

cd (dPath(1:end-11));  

clear displacements SF_
plot_fem_static(in_data,obj,resp,type_analysis,varargin{1});
