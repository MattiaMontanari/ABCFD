function [resp,LVEC] = fea_static_analysis (obj,in_data,L,dofN,dof_,type_analysis,break_K,varargin)

% =========================================================================
% FEM analysis toolbox for solid mechanics. Project started: Aug 2004
% Anton Zaicenco <a.zaicenco@codedevelopment.net>
% =========================================================================


dPath = which ('tmp_dir.txt'); % path to "tmp" directory - like: ..\fem\tmp
cd (dPath(1:end-11));
[LVEC] = LOAD_V (dofN, dof_, in_data, L);    

[dofN,EL_TYPE] = type_of_elem (in_data);
if EL_TYPE ==0 | EL_TYPE==1 | EL_TYPE==2
    if  isfield(in_data,'q')
        [LV] = frame2d_uniform_loads (in_data,L,LVEC); 
        LVEC = LVEC+LV; clear LV;
    end
end

sp_=sprintf('\n');
disp([sp_  '  ...   Load vector - completed.     Time (sec): ' num2str(toc)]);
LK=dof_;  

switch length(break_K)
    case 4
        L_1 = L(L>=break_K(1) & L<=break_K(2));
        L_2 = L(L>=break_K(3) & L<=break_K(4))-break_K(3)+1;
        obj.Ksys.Kgl_11 = obj.Ksys.Kgl_11(L_1, L_1);
        obj.Ksys.Kgl_12 = obj.Ksys.Kgl_12(L_1, L_2);
        obj.Ksys.Kgl_21 = obj.Ksys.Kgl_21(L_2, L_1);
        obj.Ksys.Kgl_22 = obj.Ksys.Kgl_22(L_2, L_2);

        CHLc_11 = chol(obj.Ksys.Kgl_11);
        disp_2 = (obj.Ksys.Kgl_22-obj.Ksys.Kgl_21*(CHLc_11\(CHLc_11'\obj.Ksys.Kgl_12)))\...
            (LVEC(end-length(L_2)+1:end)'-obj.Ksys.Kgl_21*(CHLc_11\(CHLc_11'\LVEC(1:end-length(L_2))')));
        disp_1 = CHLc_11\(CHLc_11'\ (LVEC(1:end-length(L_2))'-obj.Ksys.Kgl_12*disp_2  ));
        displacements = [disp_1 ; disp_2];
        clear CHLc_11 disp_1 disp_2;
    case 2
        resp.static.D=zeros(1,LK);
        if  isfield(in_data,'slaves')
            if  isfield(in_data,'DBC')==0
                % Master-slave MFC:
                [displacements] = MFC_master_slave (obj.Ksys.Kgl,L,LVEC,in_data.slaves,in_data.master,1);
                resp.static.D=zeros(1,LK);
                resp.static.D(L) = displacements(L); 
            else
                % Master-slave MFC + DBC's:
                [displacements] = DBC_solve (obj.Ksys.Kgl,L,LVEC,in_data);
                resp.static.D = displacements' ;
            end
        else
            % displacement BC's:
            if  isfield(in_data,'DBC')
                [displacements] = DBC_solve (obj.Ksys.Kgl,L,LVEC,in_data)
                resp.static.D = displacements' ;
            else
                CHLc = chol(obj.Ksys.Kgl(L,L));
                displacements = (CHLc\(CHLc'\LVEC(L)')); clear CHLc;
                resp.static.D(L) = displacements ;   
            end
        end
end

% -------------------------------------

disp([sp_  '  ...   Displacements - solved.      Time (sec): ' num2str(toc)]);
SF_ = zeros(size(in_data.ND,1), dofN+1);
SF_(1:size(in_data.ND,1),1)=[1:size(in_data.ND,1)]';
       
for i=1:size(in_data.ND,1)
    SF_(i,dofN-(dofN-1)+1:dofN+1) = [resp.static.D(i*dofN-(dofN-1):i*dofN)];
end;
cd (dPath(1:end-11));        % path to temp directory: ..\fem\tmp
save FEM_STATIC_DISPL.txt SF_ -ascii;
disp([sp_ '--- Static Displacements --> "FEM_STATIC_DISPL.txt": [elem# d1 ... dn]']);
clear displacements SF_
resp.static.stress = plot_fem_static(in_data,obj,resp,type_analysis,varargin{1}); 
