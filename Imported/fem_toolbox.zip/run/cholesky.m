function L=cholesky(K)


n = size(K,1);
L=zeros(n,n);

for i=1:n
    for j=1:i-1
        S=0;
        for k=1:j-1
            S=S+sum(L(i,k)*L(j,k));
        end
        L(i,j)=(K(i,j)-S)/L(j,j);
    end
    S2=sum(L(i,[1:i-1]).^2);
    L(i,i)=sqrt(K(i,i)-S2);
end

