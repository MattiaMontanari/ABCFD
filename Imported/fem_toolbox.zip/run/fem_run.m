function [obj,resp] = fem_run (in_data,type_analysis,obj,L,break_K,varargin)

% =========================================================================
% FEM analysis toolbox for solid mechanics. Project started: Aug 2004
% Anton Zaicenco <a.zaicenco@codedevelopment.net>
% =========================================================================


resp = 0; sp_=sprintf('\n');
disp([sp_ '****************** FEM started ******************']);
disp(['*************************************************']);

dPath = which ('tmp_dir.txt');     % path to "tmp" directory ..\fem\tmp
cd (dPath(1:end-11));
!time /t > tmp_dir.txt
tic;                        

[dofN] = type_of_elem (in_data);  
dof_   = size(in_data.ND,1)*dofN; 


if type_analysis(1)==1
    if  isfield(in_data,'T')
        % heat transfer problem
        [resp] = fea_heat_analysis (obj,in_data,L,dofN,dof_,...
            type_analysis,break_K,varargin{1});
    elseif size(in_data.LOAD_)~=0
        [resp,LVEC] = fea_static_analysis (obj,in_data,L,dofN,dof_,...
            type_analysis,break_K,varargin{1});
    end;
end;
% =========================================================================
if type_analysis(2)==1
    if size(in_data.dynam.TIMEH)~=0
        [resp,t] = fea_dynamic_analysis (obj,in_data,L,dof_);
    end;
end;
% =========================================================================
if type_analysis(3)==1
    if size(in_data.dynam.MODA)~=0 & size(in_data.dynam.DAMP_C)~=0
        fea_modal_analysis(obj,in_data,L,dof_);
    end;
end;
% =========================================================================

disp([sp_ '*************************************************']);
disp(['********************* END ***********************' sp_]);


